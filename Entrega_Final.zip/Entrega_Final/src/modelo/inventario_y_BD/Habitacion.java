
package modelo.inventario_y_BD;

import java.io.Serializable;
import java.util.*;

public class Habitacion implements Serializable{
	
	/**
	 * El id y ubicación..
	 */
	private int NumeroHabitacion;
	/**
	 * El número de camas dobles para adultos.
	 */
	private int Camas_dobles_adultos;
	/**
	 * El número de camas individuales para adultos.
	 */
	private int Camas_individuales_adultos;
	/**
	 * El número de camas dobles para niños.
	 */
	private int Camas_dobles_ninos;
	/**
	 * El número de camas individuales para niños.
	 */
	private int Camas_individuales_ninos;
	/**
	 * El número que representa el tipo de habitación.
	 */
	private int Tipo;
	/**
	 * Si tiene balcón.
	 */
	private boolean Balcon;
	/**
	 * Si tiene vista.
	 */
	private boolean Vista;
	/**
	 * Si tiene cocina integrada.
	 */
	private boolean Cocina;
	
	/**
	 * La capacidad tanto de niños y adultos que tiene la habitación.
	 */
	private int Capacidad_personas;
	/**
	 * La capacidad que tiene solo para adultos.
	 */
	private int Capacidad_Adultos;
	/**
	 * El número de niños que caben en las camas para niños.
	 */
	private int Capacidad_Ninos;
	/**
	 * Si tiene camas solo para niños.
	 */
	private boolean soportaNinos;
		
	/**fechas ocupacion es una lista que nos dice qué días está ocupada una habitacion y que reserva está 
	 * asociada a el día de ocupacion. El primer elmento de la lista es otra lista que contiene dos fechas 
	 * que conforman el intervalo de  ocupacion de la habitacion. Desde el segundo elemento en adelante los
	 * elemntos son listas de los inertavlos de ocupacion y en el ultimo elemento es el id_de la reserva.
	 */
	private LinkedList<ArrayList<Date>> Fechas_Ocupacion;
	
	/**
	 * el entero asignado al tipo de habitacion estandar.
	 */
	private static final int estandar = 0;
	
	/**
	 * el entero asignado al tipo de habitacion suite.
	 */
	private static final int suite = 1;
	
	/**
	 * el entero asignado al tipo de habitacion suite doble.
	 */
	private static final int suite_doble = 3;
	
	
	// ************************************************************************
	// Constructores
	// ************************************************************************
	
	/**
	 * Construye una nueva habitación e inicializa sus atributos con la información de
	 * los parámetros.La lista de ocupación se inicializa como una lista
	 * vacía.
	 * 
	 * @param Ubicacion 
	 * @param Camas_dobles_adultos
	 * @param Camas_individuales_adultos
	 * @param Camas_dobles_niños
	 * @param Camas_individuales_niños
	 * @param Tipo
	 * @param Balcon
	 * @param Vista
	 * @param Cocina
	 */
	
	public Habitacion (int Ubicacion, int Camas_dobles_adultos, int Camas_individuales_adultos, int Camas_dobles_niños, int Camas_individuales_niños, int Tipo, boolean Balcon, boolean Vista, boolean Cocina)   {
		this.NumeroHabitacion = Ubicacion;
		this.Camas_dobles_adultos = Camas_dobles_adultos;
		this.Camas_individuales_adultos = Camas_individuales_adultos;
		this.Camas_dobles_ninos = Camas_dobles_niños;
		this.Camas_individuales_ninos = Camas_individuales_niños;
		this.Tipo = Tipo;
		this.Balcon = Balcon;
		this.Vista = Vista;
		this.Cocina = Cocina;
		this.Capacidad_Adultos = Camas_dobles_adultos*2 + Camas_individuales_adultos;
		this.Capacidad_Ninos = Camas_dobles_niños*2 + Camas_individuales_niños;
		this.Capacidad_personas = this.Capacidad_Adultos + this.Capacidad_Ninos;
		this.soportaNinos = (Capacidad_Ninos == 0) ? false : true;
	}
	
	// ************************************************************************
	// Getters
	// ************************************************************************
	
	
	/**
	 * Consulta el id de la habitación que corresponde al número de la habitación.
	 * 
	 * @return el id de la habitación.
	 */
	public int getNumero() {
		return NumeroHabitacion;
	}
	/**
	 * Consulta el número de la ubicación.
	 * 
	 * @return la ubicación.
	 */
	
	public int getUbicacion() {
		return NumeroHabitacion;
	}
	/**
	 * Consulta el número de camas dobles para adultos.
	 * 
	 * @return el número de camas dobles para adultos.
	 */
	public int getCamas_dobles_adultos(){
		return Camas_dobles_adultos;
	}
	/**
	 * Consulta el número de camas individuales para adultos.
	 * 
	 * @return el número de camas individuales para adultos.
	 */
	public int getCamas_individuales_adultos(){
		return Camas_individuales_adultos;
	}
	/**
	 * Consulta el número de camas dobles para niños.
	 * 
	 * @return el número de camas dobles para niños.
	 */
	public int getCamas_dobles_ninos(){
		return Camas_dobles_ninos;
	}
	/**
	 * Consulta el número de camas individuales para niños.
	 * 
	 * @return el número de camas individuales para niños.
	 */
	public int getCamas_individuales_ninos(){
		return Camas_individuales_ninos;
	}
	/**
	 * Consulta el número que representa el tipo de habitación.
	 * 
	 * @return el numero que representa el tipo de la habitación.
	 */
	public int getNumeroTipo(){
		return Tipo;
	}
	
	/**
	 * Consulta el tipo de habitación.
	 * 
	 * @return el tipo de habitación.
	 */
	
	public String getNombreTipo() {
		
		String nombre = "";
		if (this.Tipo == estandar) {
			nombre = "estandar";
		} else if (this.Tipo == suite) {
			nombre = "suite";
		} else if (this.Tipo == suite_doble) {
			nombre = "suite doble";
		}
		
		return nombre;
		
	}
	/**
	 * Consulta si tiene balcón.
	 * 
	 * @return true si tiene balcón, false si no tiene concina balcón.
	 */
	public boolean getBalcon(){
		return Balcon;
	}
	/**
	 * Consulta si tiene vista.
	 * 
	 * @return true si tiene vista, false si no tiene concina vista.
	 */
	public boolean getVista(){
		return Vista;
	}
	/**
	 * Consulta si tiene cocina integrada.
	 * 
	 * @return true si tiene cocina integrada, false si no tiene concina integrada.
	 */
	public boolean getCocina(){
		return Cocina;
	}
	
	
	/**
	 * Consulta la capacidad tanto de niños y adultos que tiene la habitación
	 * (es la cantidad total de niños que caben).
	 * 
	 * @return la capacidad de personas.
	 */
	public int getCapacidad_personas() {
		return Capacidad_personas;
	}
	/**
	 * Consulta la capacidad que tiene solo para adultos.
	 * 
	 * @return la capacidad de adultos
	 */
	public int getCapacidad_Adultos() {
		return Capacidad_Adultos;
	}
	/**
	 * Consulta el número de niños que caben en las camas para niños.
	 * 
	 * @return la capacidad en camas para niños.
	 */
	
	public int getCapacidad_Ninos() {
		return Capacidad_Ninos;
	}
	/**
	 * Consulta si tiene camas solo para niños.
	 * 
	 * @return true si tiene camas para niños, false si no tiene camas para niños.
	 */
	public boolean soportaNinos() {
		return soportaNinos;
	}

	/**
	 * Consulta la lista con la informacuón de la ocupación
	 * 
	 * @return La lista con la informacuón de la ocupación.
	 */
	public LinkedList<ArrayList<Date>> getFechas_Ocupacion() {
		return Fechas_Ocupacion;
	}
	
	
	// ************************************************************************
	// Otros métodos
	// ************************************************************************
	
	public void Actualizar_fechas_ocupacion(Date fecha_inicial, Date fecha_final, Date id_reserva){
		
		// Conseguimos el atributo con las fechas de habitación
		LinkedList<ArrayList<Date>> Fechas_Ocupacion = this.getFechas_Ocupacion();
		
		if (Fechas_Ocupacion == null) {
			LinkedList<ArrayList<Date>> fechas_ocupacion = new LinkedList<ArrayList<Date>>();
			ArrayList<Date> intervalo_ocupacion = new ArrayList<Date>();
			
			intervalo_ocupacion.add(fecha_inicial);
			intervalo_ocupacion.add(fecha_final);
			
			fechas_ocupacion.add(intervalo_ocupacion);
			
			ArrayList<Date> intervalo_reserva = new ArrayList<Date>();
			
			intervalo_reserva.add(fecha_inicial);
			intervalo_reserva.add(fecha_final);
			intervalo_reserva.add(id_reserva);
			
			fechas_ocupacion.add(intervalo_reserva);	
			
			Fechas_Ocupacion = fechas_ocupacion;
		
		} else {
			
			ArrayList<Date> intervalo_ocupacion = Fechas_Ocupacion.get(0);
			Date fecha_inicial_ocupacion = intervalo_ocupacion.get(0);
			Date fecha_final_ocupacion = intervalo_ocupacion.get(1);
			ArrayList<Date> intervalo_reserva = new ArrayList<Date>();
			
			if (fecha_inicial.before(fecha_inicial_ocupacion) && fecha_final.before(fecha_inicial_ocupacion)) {
				intervalo_ocupacion.set(0, fecha_inicial);
				Fechas_Ocupacion.set(0, intervalo_ocupacion);
				
				intervalo_reserva.add(fecha_inicial);
				intervalo_reserva.add(fecha_final);
				intervalo_reserva.add(id_reserva);
				
				Fechas_Ocupacion.add(1,intervalo_reserva);
			
			} else if (fecha_inicial.after(fecha_final_ocupacion) && fecha_final.after(fecha_final_ocupacion)) {
				intervalo_ocupacion.set(1, fecha_final);
				Fechas_Ocupacion.set(0, intervalo_ocupacion);
				
				intervalo_reserva.add(fecha_inicial);
				intervalo_reserva.add(fecha_final);
				intervalo_reserva.add(id_reserva);
				
				Fechas_Ocupacion.addLast(intervalo_reserva);
				
			} else if (fecha_inicial.after(fecha_inicial_ocupacion) && fecha_final.before(fecha_final_ocupacion)) {

				
				intervalo_reserva.add(fecha_inicial);
				intervalo_reserva.add(fecha_final);
				intervalo_reserva.add(id_reserva);
				
				
				
				for(int i = 1; i < Fechas_Ocupacion.size()-1; i++) {
					
					Date itr_fecha_final_reserva_i = Fechas_Ocupacion.get(i).get(1);
					Date itr_fecha_inicial_reserva_i2 = Fechas_Ocupacion.get(i+1).get(0);
					
					
					if (fecha_inicial.after(itr_fecha_final_reserva_i) && fecha_final.before(itr_fecha_inicial_reserva_i2)) {
						Fechas_Ocupacion.add(i+1,intervalo_reserva);
						break;
					}
					
					else if (i == Fechas_Ocupacion.size()-2) {
						System.out.println("Error: fecha de reserva no está en medio de dos reservas");
					}
				}
				
			} 
			
			
			
		}
		
		this.Fechas_Ocupacion = Fechas_Ocupacion;
		
	}
	
	
	/**
	 * Consulta si una habitación está disponible para un rango de fechas.
	 * 
	 * @param fecha_inicial fecha inicial del rango a averiguar disponibilidad.
	 * @param fecha_final fecha final del rango a averiguar disponibilidad.
	 * @return true si la habitacion está disponible en el rango de fechas, false en caso contrario
	 */
	public Boolean estaDisponible(Date fecha_inicial, Date fecha_final) {
		
		// Solo va a retornar False en el caso en que alguna fecha sea un borde de los intervalos de ocupacion
		// o las fechas no estén entre dos intervalos
			
		boolean rpta = false;
		
		if (this.Fechas_Ocupacion != null) {
		
			ArrayList<Date> intervalo_ocupacion = this.Fechas_Ocupacion.get(0);
			Date fecha_inicial_ocupacion = intervalo_ocupacion.get(0);
			Date fecha_final_ocupacion = intervalo_ocupacion.get(1);
		
			if (fecha_inicial.after(fecha_inicial_ocupacion) && fecha_final.before(fecha_final_ocupacion)) {
				
				// Si solo hay un intervalo
				if (this.Fechas_Ocupacion.size()==2) {
					rpta = false;
				
				// Si hay más de un intervalo
				} else {
			
					for(int i = 1; i < Fechas_Ocupacion.size()-1; i++) {
						
						Date itr_fecha_final_reserva_i = Fechas_Ocupacion.get(i).get(1);
						Date itr_fecha_inicial_reserva_i2 = Fechas_Ocupacion.get(i+1).get(0);
						
						if (fecha_inicial.after(itr_fecha_final_reserva_i) && fecha_final.before(itr_fecha_inicial_reserva_i2)) {
							rpta = true;
							break;
						
						} else if (i == Fechas_Ocupacion.size()-2) {
							rpta = false;
						}	
					}
				}
			} else if ( fecha_inicial.equals(fecha_inicial_ocupacion) || fecha_final.equals(fecha_final_ocupacion) ) {
				rpta = false;
			
			} else {
				rpta = true;
			}
		
		} else {
			rpta = true;
		}
		return rpta;
	}
	
	@Override
	public String toString(){
		return Integer.toString(this.NumeroHabitacion) + "," + Integer.toString(this.Tipo) + "," +  Boolean.toString(this.Cocina);
	}
	


}
