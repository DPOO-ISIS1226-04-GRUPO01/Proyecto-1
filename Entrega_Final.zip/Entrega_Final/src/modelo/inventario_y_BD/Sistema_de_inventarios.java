package modelo.inventario_y_BD;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;

public class Sistema_de_inventarios implements Serializable{

	// ************************************************************************
	// Constructores
	// ************************************************************************
	
	/**
	 * Construye un nuevo sistema de inventarios
	 */
	public Sistema_de_inventarios() {		
	
	}
	
	// ************************************************************************
	// Métodos prinicipales
	// ************************************************************************
	
	/**
	 * Crea una tarifa para un tipo de habitación
	 * 
	 * @param tipo El tipo de habitación: "estandar", "suite" o "suite doble".
	 * @param fecha_inicial La fecha inicial para la que aplica la tarifa
	 * @param fecha_final La fecha final para la que aplica la tarifa
	 * @param dias El arreglo con los días de la semana para los que aplica la tarifa: 
	 * 				1 para Domingo, 2 para Lunes y así sucesivamente
	 * @param BD La base de datos
	 * @param precio El precio de un día en las habitaciones
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void Crear_Tarifa(String tipo, Date fecha_inicial, Date fecha_final, ArrayList<Integer> dias, BaseDatos BD, int precio) throws ClassNotFoundException, IOException {
			Tarifa tarifa = new Tarifa(tipo, fecha_inicial,fecha_final, dias, precio);
			BD.GuardarObjeto(tarifa);
	}
	
	/**
	 *  Crea o actualiza una habitacion
	 * @param Ubicacion
	 * @param Camas_dobles_adultos
	 * @param Camas_individuales_adultos
	 * @param Camas_dobles_niños
	 * @param Camas_individuales_niños
	 * @param Tipo
	 * @param Balcon
	 * @param Vista
	 * @param Cocina
	 * @param BD
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void Crear_Habitacion(int Ubicacion, int Camas_dobles_adultos, int Camas_individuales_adultos, int Camas_dobles_niños, int Camas_individuales_niños, int Tipo, boolean Balcon, boolean Vista, boolean Cocina, BaseDatos BD) throws ClassNotFoundException, IOException   {
		Habitacion habitacion = new Habitacion(Ubicacion, Camas_dobles_adultos, Camas_individuales_adultos, Camas_dobles_niños, Camas_individuales_niños, Tipo, Balcon, Vista, Cocina);
		BD.GuardarObjeto(habitacion);
	}
	
	/**
	 * Carga habitaciones a partir de un archivo txt
	 * 
	 * @param nombreArchivo .
	 * @param BD El administrador de base de datos.
	 * @throws FileNotFoundException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static void Crear_habitacion_file(String nombreArchivo, BaseDatos BD) throws FileNotFoundException, ClassNotFoundException, IOException {
		String folder = "./data/";
		String ruta = folder + nombreArchivo;
		BD.Cargar_habitacion_file(ruta);
	}
	
	/**
	 * Actualiza el inventario a patir de un archivo txt
	 * 
	 * @param nombreArchivo
	 * @param BD
	 * @throws FileNotFoundException
	 * @throws ClassNotFoundException
	 * @throws IOException
	 * @throws ParseException
	 */
	public static void editar_tarifa_habitaciones_file(String nombreArchivo, BaseDatos BD) throws FileNotFoundException, ClassNotFoundException, IOException, ParseException {
		String folder = "./data/";
		String ruta = folder + nombreArchivo;
		BD.editar_tarifa_habitaciones_file(ruta);
	}
	
	/**
	 * Calculo las fechas dentro del rango de fechas que se pase por parámetro (normalmente los próximos 365)
	 * en las que no exista una tarifa asignada para un cada tipo de habitación
	 * 
	 * @param fecha_inicial
	 * @param fecha_final
	 * @param BD
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	public static ArrayList<ArrayList<Date>> Fechas_sin_tarifa(Date fecha_inicial, Date fecha_final, BaseDatos BD) throws ClassNotFoundException, IOException {
		return BD.Fechas_sin_tarifa(fecha_inicial, fecha_final);
	}
	
	
	
}