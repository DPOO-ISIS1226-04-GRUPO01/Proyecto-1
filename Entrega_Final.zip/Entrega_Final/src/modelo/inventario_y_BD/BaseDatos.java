package modelo.inventario_y_BD;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;

import modelo.reservas_y_registro.Huesped;
import modelo.reservas_y_registro.Reserva;
import modelo.reservas_y_registro.Sistema_Reservas_y_Registro;
import modelo.servicios_y_consumo.Consumo;
import modelo.servicios_y_consumo.Producto;
import modelo.servicios_y_consumo.Servicio;
import modelo.usuarios.Usuario;

import java.util.Date;
import java.util.Calendar;



public class BaseDatos implements Serializable {
	
	 
	private static final long MILLIS_IN_A_DAY = 1000 * 60 * 60 * 24;
	
	/**
	 * El índice del mapa de tarifas para habitaciones estándar en el arreglo de tarifas
	 */
	private static final int ESTANDAR = 0;
	
	/**
	 * El índice del mapa de tarifas para habitaciones suite en el arreglo de tarifas
	 */
	private static final int SUITE = 1;
	
	/**
	 *  El índice del mapa de tarifas para habitaciones suite doble en el arreglo de tarifas
	 */
	private static final int SUITE_DOBLE = 2;
	

	public BaseDatos() {
		
	}
	
	// Funciones de creación de archivos
	
	public void CrearArchivoInventario() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoInventario.txt");
	    if (file.createNewFile()) {
	    FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoInventario.txt");
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(new HashMap<Integer, Habitacion>()); 
		objectOutputStream.close();
	    }
	   
	    
	    }
	   

	public void CrearArchivoUsuarios() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoUsuarios.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoUsuarios.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<String, Usuario>()); 
			objectOutputStream.close();
		}
	}
	

	public void CrearArchivoHuespedes() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoHuespedes.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoHuespedes.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<Integer, Huesped>()); 
			objectOutputStream.close();
	}
	}
	

	public void CrearArchivoConsumos() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoConsumos.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoConsumos.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<Integer, ArrayList<Consumo>>()); 
			objectOutputStream.close();
		}
	}
	
	public void CrearArchivoReservas() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoReservas.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoReservas.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<Date, Reserva>()); 
			objectOutputStream.close();
		}
	}
	
	public void CrearArchivoServicios() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoServicios.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoServicios.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<String, Servicio>()); 
			objectOutputStream.close();
		}
	}
	
	public void CrearArchivoMenu() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoMenu.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoMenu.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<String, Producto>()); 
			objectOutputStream.close();
		}
	}
	
	public void CrearArchivoOcupacion() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoOcupacion.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoOcupacion.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new HashMap<Date, ArrayList<Integer> >()); 
			objectOutputStream.close();
		}
	}
	
	/**
	 * Crea El archivo de tarifas que es un arreglo con 3 mapas correspondientes a los 3 tipos de habitaciones.
	 * Estos mapas tienen como llave una fecha y como valor el precio que tienen las habitaciones de un tipo
	 * en esa fecha.
	 * 
	 * @throws IOException
	 */
	public void CrearArchivoTarifa() throws IOException {
		//crea archivo si no existe
		File file = new File("./data/ArchivoTarifa.txt");
		if (file.createNewFile()) {
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoTarifa.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(new ArrayList<HashMap<Date, Integer>>()); 
			objectOutputStream.close();
		}
	}

	
// Funcion para guardar un objeto en un archivo según la clase del objeto
	
	
	public void GuardarObjeto (Object objeto) throws ClassNotFoundException, IOException {
		//guarda huesped en archivo si no existe
		Class<?> clase = objeto.getClass();
		if (clase.equals(Habitacion.class)){
			Habitacion New = (Habitacion) objeto;
			HashMap<Integer, Habitacion> inventario = GetInventario();
			inventario.put(New.getNumero(), New);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoInventario.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(inventario); 
			objectOutputStream.close();
		}
		else if(clase.equals(Consumo.class)) {
			Consumo New = (Consumo) objeto;
			HashMap<Integer, ArrayList<Consumo>> huespedes = GetConsumos();
			//PUEDE RETORNAR NULL
			ArrayList<Consumo> listaconsumos = huespedes.get(New.GetNumero());
			if ((listaconsumos)==null) {
				listaconsumos =  new  ArrayList<Consumo>();
				listaconsumos.add(New);
			}else {
			//ArrayList<Consumo> listaconsumos = huespedes.get(New.GetNumero());
			listaconsumos.add(New);
			}
			
			huespedes.put(New.GetNumero(), listaconsumos);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoConsumos.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(huespedes); 
			objectOutputStream.close();
		}

		else if(clase.equals(Huesped.class)) {
			Huesped New = (Huesped) objeto;
			HashMap<Integer, Huesped> huespedes = GetHuespedes();
			huespedes.put(New.getNumero(), New);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoHuespedes.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(huespedes); 
			objectOutputStream.close();
		}
		else if (clase.equals(Producto.class)) {
			Producto New = (Producto) objeto;
			HashMap<String, Producto> menu = GetMenu();
			menu.put(New.getNombre(), New);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoMenu.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(menu); 
			objectOutputStream.close();
		}
		
		else if (clase.equals(Servicio.class)) {
			Servicio New = (Servicio) objeto;
			HashMap<String, Servicio> servicios = GetServicios();
			servicios.put(New.getNombre(), New);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoServicios.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(servicios); 
			objectOutputStream.close();
		}
		else if (clase.equals(Usuario.class)) {
			Usuario New = (Usuario) objeto;
			HashMap<String, Usuario> usuarios = GetUsuarios();
			usuarios.put(New.getNombre(), New);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoUsuarios.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(usuarios); 
			objectOutputStream.close();
		} else if (clase.equals(Reserva.class)) {
			Reserva New = (Reserva) objeto;
			HashMap<Date, Reserva> reservas = GetReservas();
			reservas.put(New.getId_reserva() , New);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoReservas.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(reservas); 
			objectOutputStream.close();	
		}else if (clase.equals(Tarifa.class)){
			
			Tarifa New = (Tarifa) objeto;
			ArrayList<HashMap<Date, Integer>> tarifas = GetTarifa();
			
			// Crea los 3 mapas para los 3 tipos de habitaciones si el archivo está vacío
			if (tarifas.size() == 0) {
				HashMap<Date, Integer> mapa_precio0 = new HashMap<Date, Integer>();
				HashMap<Date, Integer> mapa_precio1 = new HashMap<Date, Integer>();
				HashMap<Date, Integer> mapa_precio2 = new HashMap<Date, Integer>();
				tarifas.add(mapa_precio0); // para estándar
				tarifas.add(mapa_precio1); // para suite
				tarifas.add(mapa_precio2); // para suite doble	
			}
			
			Date fecha_final = New.getfecha_final();
			Date iterador_fecha = New.getfecha_inicio();
			
			int tipo = -1;
			
			if (New.gettipo().equals("estandar")) {
				tipo = ESTANDAR;
			} else if (New.gettipo().equals("suite")) {
				tipo = SUITE;
			} else if (New.gettipo().equals("suite doble")) {
				tipo = SUITE_DOBLE;
			}
			
			
			int precio = New.getprecio();
			ArrayList<Integer> dias = New.getdias_de_la_semana();
			
			Calendar cal = Calendar.getInstance();
			
			
			while (iterador_fecha.compareTo(fecha_final) < 0 || iterador_fecha.compareTo(fecha_final)==0) {
				
				
				cal.setTime(iterador_fecha);	
				
				
				if ( dias.contains(cal.get(Calendar.DAY_OF_WEEK))) {
					
					HashMap<Date, Integer> MapaTarifas = tarifas.get(tipo);
					
					// Si la fecha no existe en el mapa
					if (MapaTarifas.get(iterador_fecha) == null) {
						MapaTarifas.put(iterador_fecha, precio);
					
					// Si ya existe debe dejar la más económica
					} else {
						int precio_actual = MapaTarifas.get(iterador_fecha);
						
						if (precio_actual > precio) {
							MapaTarifas.put(iterador_fecha, precio);}}
				}
				
				iterador_fecha = getNextDay(iterador_fecha);
			}
			
			
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoTarifa.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(tarifas); 
			objectOutputStream.close();
			}
	}
	
	
	
	
	
	
	// Funciones para obtener informacion de archivos SISTEMA DE INVENTARIOS
	
	
	public HashMap<Integer,Habitacion> GetInventario () throws IOException, ClassNotFoundException {
		//busca el inventario si existe
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoInventario.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<Integer, Habitacion> inventario = (HashMap<Integer, Habitacion>) objectInputStream.readObject();
		objectInputStream.close();
		return inventario;
		
	}
	public  ArrayList<HashMap<Date, Integer>> GetTarifa() throws IOException, ClassNotFoundException{
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoTarifa.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		ArrayList<HashMap<Date, Integer>> tarifa = (ArrayList) objectInputStream.readObject();
		objectInputStream.close();
		return tarifa;
	}
			

	// Funciones para obtener informacion de archivos SISTEMA DE REGISTROS DE CONSUMO
	
	
	public HashMap<Integer, ArrayList<Consumo>> GetConsumos() throws IOException, ClassNotFoundException {
		//busca los consumos por huesped si existen 
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoConsumos.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<Integer, ArrayList<Consumo>> consumos = (HashMap<Integer, ArrayList<Consumo>>) objectInputStream.readObject();
		objectInputStream.close();
		return consumos;
	}
	
	
	// Funciones para obtener informacion de archivos SISTEMA DE RESERVAS Y REGISTRO
		
	public HashMap<Date, Reserva> GetReservas() throws IOException, ClassNotFoundException{
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoReservas.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<Date, Reserva> reservas = (HashMap<Date, Reserva>) objectInputStream.readObject();
		objectInputStream.close();
		return reservas;
	}
	public HashMap<Date, ArrayList<Integer> > GetOcupacion () throws IOException, ClassNotFoundException {
		//busca la informacion de la Ocupacin si existe
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoOcupacion.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<Date, ArrayList<Integer> > ocupacion = (HashMap) objectInputStream.readObject();
		objectInputStream.close();
		return ocupacion;
	}
	
	
	
		public HashMap<Integer, Huesped> GetHuespedes () throws IOException, ClassNotFoundException {
		//busca la informacion de los huespedes si existe
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoHuespedes.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<Integer, Huesped> huespedes = (HashMap) objectInputStream.readObject();
		objectInputStream.close();
		return huespedes;
	}		
		
	
	// Funciones para obtener informacion de archivos ADMINISTRADOR DE USUARIOS
	
	
	public HashMap<String, Usuario> GetUsuarios () throws IOException, ClassNotFoundException {
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoUsuarios.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<String, Usuario> usuarios = (HashMap<String, Usuario>) objectInputStream.readObject();
		objectInputStream.close();
		return usuarios;
		//busca el mapa de usuarios si existe
	}
	

	// Funciones para obtener informacion de archivos SISTEMA DE SERVICIOS
	
	
	public HashMap<String, Servicio> GetServicios() throws IOException, ClassNotFoundException{
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoServicios.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<String, Servicio> servicios = (HashMap<String, Servicio>) objectInputStream.readObject();
		objectInputStream.close();
		return servicios;
	}

	
	public HashMap<String, Producto> GetMenu() throws IOException, ClassNotFoundException{
		FileInputStream fileInputStream = new FileInputStream("./data/ArchivoMenu.txt");
		ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
		HashMap<String, Producto> menu = (HashMap<String, Producto>) objectInputStream.readObject();
		objectInputStream.close();
		return menu;
	}
	

	
	
	public void EliminarObjeto(Object objeto, Class<?> clase) throws IOException, ClassNotFoundException {
		if (clase.equals(Habitacion.class)) {
			int numeroHabitacion = (int) objeto;
			HashMap<Integer, Habitacion> inventario = GetInventario();
			inventario.remove(numeroHabitacion) ;
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoInventario.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(inventario); 
			objectOutputStream.close();
		}
		else if (clase.equals(Consumo.class)) {
			int numeroHabitacion = (int) objeto;
			HashMap<Integer, ArrayList<Consumo>> consumos =  GetConsumos();
			consumos.remove(numeroHabitacion);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoConsumos.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(consumos); 
			objectOutputStream.close();
		}

		else if (clase.equals(Huesped.class)) {
			int numeroHabitacion = (int) objeto;
			HashMap<Integer, Huesped> huespedes = GetHuespedes();
			huespedes.remove(numeroHabitacion);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoHuespedes.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(huespedes); 
			objectOutputStream.close();	
		}
		else if (clase.equals(Producto.class)) {
			String nombreProducto = (String) objeto;
			HashMap<String, Producto> menu = GetMenu();
			menu.remove(nombreProducto);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoMenu.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(menu); 
			objectOutputStream.close();
		}
		else if (clase.equals(Reserva.class)) {
			Date id_Reserva = (Date) objeto;
			HashMap<Date, Reserva> reservas = GetReservas();
			reservas.remove(id_Reserva);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoReservas.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(reservas); 
			objectOutputStream.close();
		}
		else if (clase.equals(Servicio.class)) {
			String nombreServicio = (String) objeto;
			HashMap<String, Servicio> servicios = GetServicios();
			servicios.remove(nombreServicio);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoServicios.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(servicios); 
			objectOutputStream.close();
		}
		else if(clase.equals(Usuario.class)) {
			String nombreusuario = (String) objeto;
			HashMap<String, Usuario> usuarios = GetUsuarios();
			usuarios.remove(nombreusuario);
			FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoUsuarios.txt");
			ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
			objectOutputStream.writeObject(usuarios); 
			objectOutputStream.close();
		}
		
	}
	
	
	public void AbrirRegistroConsumo(int numeroHabitacion) throws ClassNotFoundException, IOException {
		HashMap<Integer, ArrayList<Consumo>> consumos = GetConsumos();
		consumos.put(numeroHabitacion, new ArrayList<>());
		
	}
	
	
	
	public void EditarServicio(String nombreServicio, int nuevoPrecio) throws ClassNotFoundException, IOException {
		HashMap<String, Servicio> servicios= GetServicios();
		Servicio servicio = servicios.get(nombreServicio);
		servicio.setPrecio(nuevoPrecio);
		GuardarObjeto(servicio);
		
		
	}
	
	public void EditarProducto(String nombreProducto, int nuevoPrecio) throws ClassNotFoundException, IOException {
		HashMap<String, Producto> productos= GetMenu();
		Producto producto = productos.get(nombreProducto);
		producto.setPrecio(nuevoPrecio);
		GuardarObjeto(producto);
	}

	// ************************************************************************
	// Métodos para sistema de reserva
	// ************************************************************************
	

	/**
	 * 
	 * Calcula las habitaciones de la reserva de acuerdo con la cantidad de huéspedes y sus 
	 * características (si son niños o si no necesitan cama en el caso de ser menores de dos años).
	 * 
	 * @param huespedes El arreglo de los huéspedes de una reserva
	 * @param fecha_inicio_iterador La fecha inicial con la que el método calcula la ocupacion
	 * @param fecha_final La fecha final de la reserva
	 * @param id_reserva El identificador de la reserva, correspondiente a la fecha y hora de la creación de la reserva
	 * @param fecha_inicio La fecha inicial de la reserva originalmente
	 * 
	 * @return El arreglo con las habitaciones asignadas a los huespedes
	 * @throws IOException 
	 * @throws ClassNotFoundException 
	 */
	
	public ArrayList<HashMap<Integer, Habitacion>> CalcularHabitacionesReserva(int num_adultos, int num_ninos, int num_bebes_cama, Date fecha_inicio, Date fecha_final, Date id_reserva, HashMap<Date, ArrayList<Integer> > Mapa_Ocupacion, Date fecha_inicio_iterador) throws ClassNotFoundException, IOException{
		
		
		ArrayList<Integer> Lista_Habitaciones_Desocupadas = Mapa_Ocupacion.get(fecha_inicio_iterador);
		
		// Si no hay ninguna ocupacion para la fecha inicial
		if( Lista_Habitaciones_Desocupadas == null && fecha_inicio_iterador.before(fecha_final)) {
			
			return CalcularHabitacionesReserva(num_adultos, num_ninos, num_bebes_cama, fecha_inicio, fecha_final, id_reserva, Mapa_Ocupacion, getNextDay(fecha_inicio_iterador));
		
		// Si no hay ninguna ocupacion en el intervalo de fechas
		} else if (Lista_Habitaciones_Desocupadas == null && fecha_inicio_iterador.compareTo(fecha_final)==0) {
			
			HashMap<Integer, Habitacion> Mapa_Inventario = GetInventario();
			ArrayList<Integer> Lista_Habitaciones_Disponibles = new ArrayList<>(Mapa_Inventario.keySet());			
					
			return ObtenerHabitaciones(num_adultos, num_ninos, num_bebes_cama, Lista_Habitaciones_Disponibles);
		
		
		} else {
			
			int num_ninos_bebes = num_ninos + num_bebes_cama;
			
			
			ArrayList<Integer> capacidad_huespedes = Capacidad_Huespedes(Lista_Habitaciones_Desocupadas);
			int Capacidad_Ninos_Habitaciones_Desocupadas = capacidad_huespedes.get(0)-num_adultos; // restamos el numero de adultos
			int Capacidad_Adultos_Habitaciones_Desocupadas = capacidad_huespedes.get(1);
			
			
			
			// Si en algún día del intervalo no hay suficientes habitaciones disponibles
			if (Capacidad_Adultos_Habitaciones_Desocupadas < num_adultos || Capacidad_Ninos_Habitaciones_Desocupadas < num_ninos_bebes) {
				
				ArrayList<HashMap<Integer, Habitacion>> Arreglo_Vacio = new ArrayList<HashMap<Integer, Habitacion>>();
				return Arreglo_Vacio;
			
			// Si es probable que haya habitaciones disponibles
			} else {
								
				HashMap<Integer, Habitacion> Mapa_Inventario = GetInventario();
				ArrayList<Integer> Lista_Habitaciones_Disponibles = new ArrayList<Integer>();
				
				for(int i = 0; i < Lista_Habitaciones_Desocupadas.size(); i++) {
					
					//obtenemos la habitacion del inventario
					Habitacion habitacion = Mapa_Inventario.get(Lista_Habitaciones_Desocupadas.get(i));
					
					//Si esta disponible para las fecha
					if(habitacion.estaDisponible(fecha_inicio_iterador, fecha_final)) {
						Lista_Habitaciones_Disponibles.add(habitacion.getNumero());
					}
				}
				
				ArrayList<Integer> capacidad_huespedes_disponible = Capacidad_Huespedes(Lista_Habitaciones_Disponibles);
				int Capacidad_Ninos_Habitaciones_Disponibles = capacidad_huespedes_disponible.get(0)-num_adultos; // restamos el numero de adultos
				int Capacidad_Adultos_Habitaciones_Disponibles = capacidad_huespedes_disponible.get(1);
				
				
				// Si no hay suficientes habitaciones disponibles
				if (Capacidad_Adultos_Habitaciones_Disponibles < num_adultos || Capacidad_Ninos_Habitaciones_Disponibles < num_ninos_bebes) {
					ArrayList<HashMap<Integer, Habitacion>> Arreglo_Vacio = new ArrayList<HashMap<Integer, Habitacion>>();
					return Arreglo_Vacio;	
				} else {
					return ObtenerHabitaciones(num_adultos, num_ninos, num_bebes_cama, Lista_Habitaciones_Disponibles);
				}
				
			
			}
		}
		
		
	}
	
	
	/**
	 * 
	 * Calcula óptimamente las habitaciones para un grupo de huéspedes de una lista de habitaciones disponibles de acuerdo a la cantidad y tipo de huéspedes.
	 * 
	 * @param num_adultos cantidad de adultos 
	 * @param num_ninos cantidad de niños
	 * @param num_bebes_cama cantidad de niños menores de dos años que necesitan cama
	 * @param Lista_Habitaciones_Disponibles El arreglo con las habitaciones disponibles
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	
	public ArrayList<HashMap<Integer, Habitacion>> ObtenerHabitaciones(int num_adultos, int num_ninos, int num_bebes_cama, ArrayList<Integer> Lista_Habitaciones_Disponibles) throws ClassNotFoundException, IOException{
		
		
		ArrayList<HashMap<Integer, Habitacion>> habitaciones = new ArrayList<HashMap<Integer, Habitacion>>();
		HashMap<Integer, Habitacion> habitaciones_ninos = new HashMap<Integer, Habitacion>(); //return habitaciones con camas exclusivamente para niños
		HashMap<Integer, Habitacion> habitaciones_adultos = new HashMap<Integer, Habitacion>(); //return habitaciones sin camas exclusivamente para niños
		
		
		ArrayList<ArrayList<Integer>> Habitaciones_Ninos_Adultos = getHabitaciones_Adultos_Ninos(Lista_Habitaciones_Disponibles);
		
		ArrayList<Integer> Habitaciones_Ninos = Habitaciones_Ninos_Adultos.get(0);
		ArrayList<Integer> Habitaciones_Adultos = Habitaciones_Ninos_Adultos.get(1);
		HashMap<Integer, Habitacion> Mapa_Inventario = GetInventario();
		
		
		
		
		int num_ninos_bebes_cama = num_ninos + num_bebes_cama;
		int adultos_con_habitacion = 0;
		int ninos_bebes_cama_con_habitacion = 0;
		
		
		if (num_ninos_bebes_cama == 0) {
			
			if (Habitaciones_Adultos.size() > 0) {
				
				int i = 0;
				do {
					Habitacion habitacion = Mapa_Inventario.get(Habitaciones_Adultos.get(i));
					adultos_con_habitacion += habitacion.getCapacidad_Adultos();
					habitaciones_adultos.put(habitacion.getNumero(), habitacion);
					i++;
					
				} while(adultos_con_habitacion < num_adultos && i < Habitaciones_Adultos.size());
				
				
			} if (Habitaciones_Adultos.size()==0 || adultos_con_habitacion < num_adultos) {
					
					int j = 0;
					do {
						Habitacion habitacion = Mapa_Inventario.get(Habitaciones_Ninos.get(j));
						adultos_con_habitacion += habitacion.getCapacidad_Adultos();
						habitaciones_ninos.put(habitacion.getNumero(), habitacion);
						j++;
						
					} while(adultos_con_habitacion < num_adultos && j < Habitaciones_Ninos.size());
				}
			 
		} else {
			
			if (Habitaciones_Ninos.size() > 0) {
				
				int i = 0;
				do {
					Habitacion habitacion = Mapa_Inventario.get(Habitaciones_Ninos.get(i));
					ninos_bebes_cama_con_habitacion += habitacion.getCapacidad_Ninos();
					adultos_con_habitacion += habitacion.getCapacidad_Adultos();
					habitaciones_ninos.put(habitacion.getNumero(), habitacion);
					i++;
					
				} while(ninos_bebes_cama_con_habitacion < num_ninos_bebes_cama && i < Habitaciones_Ninos.size());
				
			} if (Habitaciones_Ninos.size()==0 || adultos_con_habitacion < num_adultos ||  ninos_bebes_cama_con_habitacion < num_ninos_bebes_cama) {
					
					int j = 0;
					do {
						Habitacion habitacion = Mapa_Inventario.get(Habitaciones_Adultos.get(j));
						ninos_bebes_cama_con_habitacion += habitacion.getCapacidad_Ninos();
						adultos_con_habitacion += habitacion.getCapacidad_Adultos();
						
						if (adultos_con_habitacion > num_adultos && ninos_bebes_cama_con_habitacion < num_ninos_bebes_cama) {
							// habitaciones de exceso que tomó adultos que debo asignar a niños 
							int habitaciones_exceso = adultos_con_habitacion - num_adultos;
							ninos_bebes_cama_con_habitacion += habitaciones_exceso;	
						}
						
						habitaciones_adultos.put(habitacion.getNumero(), habitacion);
						j++;
						
					} while( adultos_con_habitacion < num_adultos && j < Habitaciones_Adultos.size());
					
					if (ninos_bebes_cama_con_habitacion < num_ninos_bebes_cama) {
						
						int k = j;
						
						do {
							Habitacion habitacion = Mapa_Inventario.get(Habitaciones_Adultos.get(k));
							ninos_bebes_cama_con_habitacion += habitacion.getCapacidad_personas();
							habitaciones_adultos.put(habitacion.getNumero(), habitacion);
							k++;
							
						} while( ninos_bebes_cama_con_habitacion < num_ninos_bebes_cama && k < Habitaciones_Adultos.size());
						
					}
			}		
		}
		
		habitaciones.add(habitaciones_ninos);
		habitaciones.add(habitaciones_adultos);
		
		return habitaciones;
	}
	
	
	
	/**
	 * Actualiza el archivo de Ocupacion cuando se crea una nueva reserva, quitando de la lista de las
	 * habitaciones desocupadas a las habiatciones de la reseva para una fecha específica.
	 * 
	 * @param fecha Fecha de la que se quitan las  habiatciones desocupacdas
	 * @param id_habitaciones Habitaciones a ser removidas de la lista de habitaciones desocupadas
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	
	public void ActualizarOcupacion(Date fecha, ArrayList<Integer> id_habitaciones) throws IOException, ClassNotFoundException {
		
		HashMap<Date, ArrayList<Integer> > Mapa_Ocupacion = GetOcupacion();
		HashMap<Integer, Habitacion> Mapa_Inventario = GetInventario();
		
		ArrayList<Integer> Lista_Habitaciones_Desocupadas = new ArrayList<Integer>();
		
		// si la fecha no existe
		if (Mapa_Ocupacion.get(fecha) == null) {
			Lista_Habitaciones_Desocupadas = new ArrayList<>(Mapa_Inventario.keySet());	
		} 
		// Si la fecha ya existe
		else {
			Lista_Habitaciones_Desocupadas = Mapa_Ocupacion.get(fecha);
		}
		
		// quitamos las habitaciones de las desocupadas en la fecha especficiada
		for(int i = 0; i < id_habitaciones.size(); i++) {
			Lista_Habitaciones_Desocupadas.remove(id_habitaciones.get(i));
		}
		
		Mapa_Ocupacion.put(fecha, Lista_Habitaciones_Desocupadas);
		
		FileOutputStream fileOutputStream = new FileOutputStream("./data/ArchivoOcupacion.txt");
		ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
		objectOutputStream.writeObject(Mapa_Ocupacion); 
		objectOutputStream.close();
	}
	
	
	/**
	 * 
	 * Calcula óptimamente las habitaciones para un grupo de huéspedes de una lista de habitaciones disponibles de acuerdo a la cantidad y tipo de huéspedes.
	 * 
	 * @param num_adultos cantidad de adultos 
	 * @param num_ninos cantidad de niños
	 * @param num_bebes_cama cantidad de niños menores de dos años que necesitan cama
	 * @param Lista_Habitaciones_Disponibles El arreglo con las habitaciones disponibles
	 * @return
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	
	public void AsignarHabitacionesRegistro(ArrayList<Huesped> adultos, ArrayList<Huesped> ninos, ArrayList<Huesped> bebes_cama, ArrayList<Huesped> bebes_no_cama, ArrayList<Integer> Habitaciones_ninos, ArrayList<Integer> Habitaciones_adultos) throws ClassNotFoundException, IOException{
		
		
		
	}
	
	// ************************************************************************
	// Métodos helper para sistema de reserva
	// ************************************************************************
	
	/**
	 * Calcula la capacidad de huéspedes (tanto de niños como de adultos) que tiene una lista de habitaciones. 
	 * 
	 * @param lista_Habitaciones_Desocupadas La lista para obtener la capacidad de huéspedes.
	 * @return El arreglo con la capacidad de niños en la primera posición y con la capacidad de adultos en la segunda posición.
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	
	private ArrayList<Integer> Capacidad_Huespedes(ArrayList<Integer> lista_Habitaciones_Desocupadas) throws ClassNotFoundException, IOException {
		
		
		
		ArrayList<Integer> Arreglo_capacidades = new ArrayList<Integer>();
		HashMap<Integer, Habitacion> Mapa_Inventario = GetInventario();
		int capacidad_ninos = 0;
		int capacidad_adultos = 0;
		
		if (lista_Habitaciones_Desocupadas.size()!=0) {
		
		
			for(int i = 0; i < lista_Habitaciones_Desocupadas.size(); i++) {
				Habitacion habitacion = Mapa_Inventario.get(lista_Habitaciones_Desocupadas.get(i));
				capacidad_ninos += habitacion.getCapacidad_personas(); // los niños caben en camas de adultos también
				capacidad_adultos += habitacion.getCapacidad_Adultos();
			}
		}
		
		Arreglo_capacidades.add(capacidad_ninos);
		Arreglo_capacidades.add(capacidad_adultos);
		
		return Arreglo_capacidades;

	}
	

	
	/**
	 * Obtiene las habitaciones con camas exclusivas para niños y las habitaciones sin camas exclusivas para niños a partir de una lista de id de habitaciones
	 * 
	 * @param Lista_Habitaciones_Disponibles El arreglo con la lista de id de habitaciones para clasificar
	 * @return Un arreglo donde el primer elemento es un arreglo con las habitaciones con camas exclusivas para niños y el segundo elemento un arreglo con las habitaciones sin camas exclusivas para niños a partir de una lista de id de habitaciones
	 * @throws ClassNotFoundException
	 * @throws IOException
	 */
	
	public ArrayList<ArrayList<Integer>> getHabitaciones_Adultos_Ninos(ArrayList<Integer> Lista_Habitaciones_Disponibles) throws ClassNotFoundException, IOException{
	
	
		ArrayList<ArrayList<Integer>> Arreglo_Habitaciones = new ArrayList<ArrayList<Integer>>();
		ArrayList<Integer> Habitaciones_Ninos = new ArrayList<Integer>();
		ArrayList<Integer> Habitaciones_Adultos = new ArrayList<Integer>();
		
		HashMap<Integer, Habitacion> Mapa_Inventario = GetInventario();
		
		for(int i = 0; i < Lista_Habitaciones_Disponibles.size(); i++) {
			Habitacion habitacion = Mapa_Inventario.get(Lista_Habitaciones_Disponibles.get(i));
			if (habitacion.soportaNinos()) {
				Habitaciones_Ninos.add(habitacion.getNumero());
			} else {
				Habitaciones_Adultos.add(habitacion.getNumero());
			}
		}
		
		Arreglo_Habitaciones.add(Habitaciones_Ninos);
		Arreglo_Habitaciones.add(Habitaciones_Adultos);
		
		return Arreglo_Habitaciones;
		
	}
	
	/**
	 * Calcula la fecha siguiente a la que es pasada por parámetro
	 * @param date fecha a la que se le quiere calcular la fecha siguiente
	 * @return la fecha siguiente a la pasada por parámetro
	 */
	
	public static Date getNextDay(Date date)
	{
	  return new Date(date.getTime() + MILLIS_IN_A_DAY);
	}
	
	
	// ************************************************************************
	// Métodos para sistema de inventario 
	// ************************************************************************
	
	/**
	 * Las partes de un archivo txt con la info de las habitaciones debe ser de la forma 
	 * Ubicación;Camas dobles adultos; Camas individuales adultos;camas  dobles niños; camas 
	 * individuales niños; tipo;balcón;vista;cocina integrada
	 * 
	 * para tipo 0 es estándar, 1 es suite y 2 es suite dobke
	 * para los útlimos tres es verdadero o falso 
	 * 
	 * @param ruta
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 */
	public void Cargar_habitacion_file(String ruta) throws FileNotFoundException, IOException, ClassNotFoundException {
		
		File file = new File(ruta);
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		String linea = br.readLine();
		
		while (linea != null) {

			String[] partes = linea.split(";");
			int id_y_ubicacion = Integer.parseInt(partes[0]);
			int camas_dobles_adultos = Integer.parseInt(partes[1]);
			int camas_individuales_adultos = Integer.parseInt(partes[2]);
			int camas_dobles_ninos = Integer.parseInt(partes[3]);
			int camas_individuales_ninos = Integer.parseInt(partes[4]);
			int tipo = Integer.parseInt(partes[5]);
			boolean balcon = partes[6].equals("verdadero") ? true : false;
			boolean vista = partes[7].equals("verdadero") ? true : false;
			boolean cocina = partes[8].equals("verdadero") ? true : false;
			
			Habitacion habitacion = new Habitacion(id_y_ubicacion, camas_dobles_adultos, camas_individuales_adultos, camas_dobles_ninos, camas_individuales_ninos, tipo, balcon, vista, cocina);
			
			GuardarObjeto(habitacion);
			
			linea = br.readLine();
			
		}
			
			
		br.close();
		
		}
	
	/**
	 * 
	 * Las partes de un archivo txt con la info de las habitaciones debe ser de la forma 
	 * Tarifa('estándar', 'suite' o 'suite doble'); fecha_inicial ('dd/MM/yyyy'); 
	 * fecha_final ('dd/MM/yyyy'); dias ((1 para Domingo, 2 para lunes, etc), separados por comas);
	 * precio
	 * 
	 * @param ruta
	 * @throws FileNotFoundException
	 * @throws IOException
	 * @throws ClassNotFoundException
	 * @throws ParseException 
	 */
	public void editar_tarifa_habitaciones_file(String ruta) throws FileNotFoundException, IOException, ClassNotFoundException, ParseException {
		
		File file = new File(ruta);
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		String linea = br.readLine();
		
		while (linea != null) {
			
			String[] partes = linea.split(";");
			
			String tipo = partes[0];
		
			
			String fecha_inicial_raw = partes[1];
			Date fecha_inicial = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_inicial_raw);
			
			String fecha_final_raw = partes[2];
			Date fecha_final = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_final_raw);
			
			String dias_raw = partes[3];
			String[] dias_raw1 = dias_raw.split(",");
			ArrayList<Integer> dias = new ArrayList<Integer>();
			
			for (String i: dias_raw1) {
				int num = Integer.parseInt(i);
				dias.add(num);
			}
			int precio = Integer.parseInt(partes[4]);
			
			Tarifa tarifa = new Tarifa(tipo,fecha_inicial,fecha_final,dias,precio);
			
			GuardarObjeto(tarifa);
			
			linea = br.readLine();
			
		}
		
		br.close();
	}	
		
	public ArrayList<ArrayList<Date>> Fechas_sin_tarifa(Date fecha_inicial, Date fecha_final) throws ClassNotFoundException, IOException{
		
		ArrayList<HashMap<Date, Integer>> ArrTarifas = GetTarifa(); //El arreglo con las tarifas
		ArrayList<ArrayList<Date>> Respuesta = new ArrayList<ArrayList<Date>>(); // El return
		
		HashMap<Date, Integer> Mapa_tarifas_estandar = ArrTarifas.get(ESTANDAR);
		HashMap<Date, Integer> Mapa_tarifas_suite = ArrTarifas.get(SUITE);
		HashMap<Date, Integer> Mapa_tarifas_suite_doble = ArrTarifas.get(SUITE_DOBLE);
		
		ArrayList<Date> fechas_sin_tarifa_estandar = new ArrayList<Date>();
		ArrayList<Date> fechas_sin_tarifa_suite = new ArrayList<Date>();
		ArrayList<Date> fechas_sin_tarifa_suite_doble = new ArrayList<Date>();		
		
		Date iterador_fecha = fecha_inicial;
		while (iterador_fecha.compareTo(fecha_final) < 0 || iterador_fecha.compareTo(fecha_final)==0) {
			
			if (Mapa_tarifas_estandar.get(iterador_fecha) == null) {
				
				fechas_sin_tarifa_estandar.add(iterador_fecha);
			
			} else if (Mapa_tarifas_suite.get(iterador_fecha) == null) {
				
				fechas_sin_tarifa_suite.add(iterador_fecha);
			
			} else if (Mapa_tarifas_suite_doble.get(iterador_fecha) == null) {
				
				fechas_sin_tarifa_suite_doble.add(iterador_fecha);
			
			} 
			iterador_fecha = getNextDay(iterador_fecha);
			
		}
		
		Respuesta.add(fechas_sin_tarifa_estandar);
		Respuesta.add(fechas_sin_tarifa_suite);
		Respuesta.add(fechas_sin_tarifa_suite_doble);
		
		return Respuesta;
		
	}
	
	public ArrayList<Integer> reservar_file(String ruta, Date id_reserva) throws IOException, ParseException, ClassNotFoundException{

		ArrayList<Integer> respuesta = new ArrayList<Integer>();
		
		File file = new File(ruta);
		
		BufferedReader br = new BufferedReader(new FileReader(file));
		String linea = br.readLine();
		
		while (linea != null) {
			
			String[] partes = linea.split(";");
			
			String nombreHuesped =  partes[0];
			int documentoHuesped = Integer.parseInt(partes[1]);
			String correoHuesped =  partes[2];
			int celularHuesped = Integer.parseInt(partes[3]);
			Huesped huespedPrincipal = new Huesped(nombreHuesped, correoHuesped, documentoHuesped, celularHuesped, Huesped.ADULTO);
			
			int Num_adultos = Integer.parseInt(partes[4]);
			int Num_ninos = Integer.parseInt(partes[5]);
			int Num_bebes_no_cama = Integer.parseInt(partes[6]);
			int Num_bebes_cama = Integer.parseInt(partes[7]);
			
			String fecha_inicial_raw = partes[8];
			Date fecha_inicial = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_inicial_raw);
			
			String fecha_final_raw = partes[9];
			Date fecha_final = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_final_raw);
			
			respuesta = Sistema_Reservas_y_Registro.Crear_reserva(huespedPrincipal, Num_adultos, Num_ninos, Num_bebes_no_cama, Num_bebes_cama, fecha_inicial, fecha_final, id_reserva, this);
			
			linea = br.readLine();
			
		}
		
		br.close();
		
		return respuesta;
	
	}

		
	
	
}