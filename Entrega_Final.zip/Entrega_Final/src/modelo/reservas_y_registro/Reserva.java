package modelo.reservas_y_registro;

import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;



/**
 * Esta clase encapsula la información sobre los reservas y calcula algunas cosas
 * sobre estas.
 */
public class Reserva implements Serializable{
	
	// ************************************************************************
	// Atributos
	// ************************************************************************
	
	/**
	 * Arreglo con con los huéspedes de la reserva. El primer huésped es el cliente principal.
	 */
	private ArrayList<Huesped> Huespedes;
	
	/**
	 * Huesped principal.
	 */
	private Huesped Huesped_principal;
	
	/**
	 * Fecha de inicio de la reserva.
	 */
	private Date Fecha_inicio;
	
	/**
	 * Fecha final de la reserva.
	 */
	private Date Fecha_final;
	
	/**
	 *Id de la reserva que corresponde a la fecha y hora de la creacion de la reserva.
	 */
	private Date Id_reserva;
	
	/**
	 * Arreglo con los id de las habitaciones con camas exclusivamente para niños.
	 */
	private ArrayList<Integer> Id_habitaciones_ninos; 
	
	/**
	 * Arreglo con los id de las habitaciones sin camas exclusivamente para niños.
	 */
	private ArrayList<Integer> Id_habitaciones_adultos; 
	
	/**
	 * Numero total de clientes.
	 */
	private int Cantidad_clientes;

	// ************************************************************************
	// Constructor
	// ************************************************************************

	/**
	 * Construye una nueva reserva e inicializa sus atributos con la información de
	 * los parámetros. 
	 * 
	 * @param Clientes Un arreglo con los clientes. El primer elemento es el Cliente principal.
	 * @param Fecha_inicio La fecha de inicio de la reserva.
	 * @param Fecha_final La fecha final de la reserva.
	 * @param Id_reserva El id de la reserva que corresponde a la fecha y hora de la creacion de la reserva.
	 * @param Id_habitaciones_ninos El arreglo con los id de las habitaciones con camas exclusivamente para niños asociadas a la reserva.
	 * @param Id_habitaciones_adultos El arreglo con los id de las habitaciones sin camas exclusivamente para niños asociadas a la reserva.
	 *
	 */
	
	public Reserva(Huesped Huesped_principal, Date Fecha_inicio, Date Fecha_final, Date Id_reserva, ArrayList<Integer> Id_habitaciones_ninos, ArrayList<Integer> Id_habitaciones_adultos) {
		this.Huesped_principal = Huesped_principal;
		this.Fecha_inicio = Fecha_inicio;
		this.Fecha_final = Fecha_final;
		this.Id_reserva = Id_reserva;
		this.Id_habitaciones_ninos = Id_habitaciones_ninos;
		this.Id_habitaciones_adultos = Id_habitaciones_adultos;
	}
	
	// ************************************************************************
	// Getters
	// ************************************************************************

	/**
	 * Consulta los huéspedes asociadas a la reserva.
	 * 
	 * @return El arreglo de huéspedes asociadas a la reserva.
	 */
	public ArrayList<Huesped> getHuespedes() {
		return Huespedes;
	}
	
	/**
	 * Consulta el huésped principal asociado a la reserva.
	 * 
	 * @return El huésped principal.
	 */
	public Huesped getHuespedPrincipal() {
		return Huesped_principal;
	}
	
	/**
	 * Consulta la fecha de inicio de la reserva.
	 * 
	 * @return La fecha de inicio de la reserva.
	 */
	public Date getFecha_Inicio() {
		return Fecha_inicio;
	}
	
	/**
	 * Consulta la fecha final de la reserva.
	 * 
	 * @return La fecha final de la reserva.
	 */
	public Date getFecha_Final() {
		return Fecha_final;
	}
	
	/**
	 * Consulta el id de la reserva.
	 * 
	 * @return El id de la reserva.
	 */
	public Date getId_reserva() {
		return Id_reserva;
	}

	/**
	 * Consulta las habitaciones con camas exclusivamente para niños asociadas a la reserva.
	 * 
	 * @return Las habitaciones con camas exclusivamente para niños asociadas a la reserva asociadas a la reserva.
	 */
	public ArrayList<Integer> getId_habitaciones_ninos() {
		return Id_habitaciones_ninos;
	}
	
	/**
	 * Consulta las habitaciones sin camas exclusivamente para niños asociadas a la reserva asociadas a la reserva.
	 * 
	 * @return Las habitaciones sin camas exclusivamente para niños asociadas a la reserva asociadas a la reserva.
	 */
	public ArrayList<Integer> getId_habitaciones_adultos() {
		return Id_habitaciones_adultos;
	}
	
	@Override
	public String toString() {
		return "Huesped principal: " + Huesped_principal + "Fecha inicio: " + Fecha_inicio +  "Fecha final: " + Fecha_final + "Id_reserva: " + Id_reserva;
	}
	


}