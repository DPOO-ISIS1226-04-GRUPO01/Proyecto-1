package modelo.reservas_y_registro;

import java.io.Serializable;
import java.util.Date;

public class Huesped implements Serializable {

	public static final int ADULTO = 0;
	
	public static final int NINO = 1;
	
	public static final int BEBE_CAMA = 2;
	
	public static final int BEBE_NO_CAMA = 3;
	
	private String Nombre;
	
	private String Correo;
	
	private int Documento;
	
	private int Celular;

	private int NumeroHabitacion;
	
	private int Tipo;
	
	private Date reserva;
	

	public Huesped(String nombre, String Correo, int Documento, int Celular, int Tipo) {
		this.Nombre = nombre;
		this.Correo = Correo;
		this.Documento = Documento;
		this.Celular = Celular;
	}

	public int getNumero() {
		return NumeroHabitacion;
	}
	
	@Override
	public String toString() {
		return "Nombre: " + Nombre;
	}

}
