package modelo.reservas_y_registro;

import java.io.Serializable;

public class Registro implements Serializable {

	public Registro() {
		
	}

}
