package modelo.reservas_y_registro;


import java.io.IOException;
import java.util.*;

import modelo.inventario_y_BD.BaseDatos;
import modelo.inventario_y_BD.Habitacion;

import java.io.Serializable;
import java.text.ParseException;

/**
 * Esta clase encapsula la información sobre las reservas y el registro de los huéspedes y hace cálculos
 * sobre esta información.
 */

public class Sistema_Reservas_y_Registro implements Serializable{
	
	
	/**
	 * Variable para sumar al getNextDay.
	 */
	private static final long MILLIS_IN_A_DAY = 1000 * 60 * 60 * 24;
	
	// ************************************************************************
	// Constructores
	// ************************************************************************
	
	/**
	 * Construye un nuevo sistema de reservas y registro
	 */
	
	// ************************************************************************
	// Métodos prinicipales
	// ************************************************************************
	
	public Sistema_Reservas_y_Registro() {
		
	}
	
	/**
	 * Crea una nueva reserva, actualiza la ocupacion del hotel, y la información de las habitaciones en el inventario.
	 * 
	 * @param huespedes Un arreglo con los huéspedes. El primer elemento es el huésped principal.
	 * @param fecha_inicio La fecha de inicio de la reserva.
	 * @param fecha_final La fecha final de la reserva.
	 * @param id_reserva El id de la reserva que corresponde a la fecha y hora de la creación de la reserva.
	 * @param BD el administrador de base de datos del hotel.
	 * 
	 */
	public static ArrayList<Integer> Crear_reserva(Huesped huesped_principal, int num_adultos, int num_ninos, int num_bebes_no_cama, int num_bebes_cama, Date fecha_inicio, Date fecha_final, Date id_reserva, BaseDatos BD) throws ClassNotFoundException, IOException {
		
		ArrayList<Integer> id_habitaciones = new ArrayList<>(); // retorno
		ArrayList<Integer> id_habitaciones_ninos = new ArrayList<>();
		ArrayList<Integer> id_habitaciones_adultos = new ArrayList<>();
		
		
		HashMap<Date, ArrayList<Integer> > Mapa_Ocupacion = BD.GetOcupacion();
		
		// Se calculan las habitaciones de la reserva de acuerdo a la cantidad de  y sus características (si son niños o si no necesitan cama en el caso de ser menores de dos años)
		ArrayList<HashMap<Integer, Habitacion>> habitaciones_reserva = BD.CalcularHabitacionesReserva(num_adultos, num_ninos, num_bebes_cama, fecha_inicio, fecha_final, id_reserva, Mapa_Ocupacion, fecha_inicio);
		
		//Se actualiza la información de las habitaciones en el inventario
		HashMap<Integer, Habitacion> habitaciones_reserva_ninos = habitaciones_reserva.get(0);
		HashMap<Integer, Habitacion> habitaciones_reserva_adultos = habitaciones_reserva.get(1);
		
		
		
		if (habitaciones_reserva_ninos.size()>0) {
			
			habitaciones_reserva_ninos.forEach((id, habitacion)->{
			try {
				habitacion.Actualizar_fechas_ocupacion(fecha_inicio, fecha_final, id_reserva);
				BD.GuardarObjeto(habitacion);
				
			} catch (ClassNotFoundException | IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			});	
			
			// Se obtiene un arreglo con los id de las habitaciones con camas exclusivamente para niños de la reserva.
			id_habitaciones_ninos = new ArrayList<>(habitaciones_reserva_ninos.keySet());
			//Agregamos los id a la lista final
			id_habitaciones.addAll(id_habitaciones_ninos);
		}
	
		if (habitaciones_reserva_adultos.size()>0) {
			
			habitaciones_reserva_adultos.forEach((id, habitacion)->{
				try {
					habitacion.Actualizar_fechas_ocupacion(fecha_inicio, fecha_final, id_reserva);
					BD.GuardarObjeto(habitacion);
				
				} catch (ClassNotFoundException | IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			});
			// Se obtiene un arreglo con los id de las habitaciones sin camas exclusivamente para niños de la reserva.
			id_habitaciones_adultos = new ArrayList<>(habitaciones_reserva_adultos.keySet());
			//Agregamos los id a la lista final
			id_habitaciones.addAll(id_habitaciones_adultos);
		}
		
		// Se crea una nueva reserva y se guarda la reserva
		Reserva reserva = new Reserva(huesped_principal, fecha_inicio, fecha_final, id_reserva, id_habitaciones_ninos, id_habitaciones_adultos);
		BD.GuardarObjeto(reserva);
		
		//Se actualiza el archivo ocupación

		for(Date iterador_fecha = fecha_inicio; iterador_fecha.compareTo(fecha_final) < 0 || iterador_fecha.compareTo(fecha_final)==0; iterador_fecha = getNextDay(iterador_fecha)) {
			BD.ActualizarOcupacion(iterador_fecha, id_habitaciones);
		}
								
		return id_habitaciones;
			
	}
	
	public static ArrayList<Integer> reservar_file(String nombreArchivo, Date id_reserva, BaseDatos BD) throws ClassNotFoundException, IOException, ParseException {
		String folder = "./data/";
		String ruta = folder + nombreArchivo;
		return BD.reservar_file(ruta, id_reserva);
	}
	
	public static void Hacer_registro(ArrayList<Huesped> huespedes, Date id_reserva) {
		
	}
	
	// ************************************************************************
	// Métodos helper
	// ************************************************************************
	
	
	private static Date getNextDay(Date date)
	{
	  return new Date(date.getTime() + MILLIS_IN_A_DAY);
	}
	
	
	
	
		
}