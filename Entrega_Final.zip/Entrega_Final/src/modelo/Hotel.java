package modelo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import modelo.inventario_y_BD.BaseDatos;
import modelo.inventario_y_BD.Habitacion;
import modelo.inventario_y_BD.Sistema_de_inventarios;
import modelo.reservas_y_registro.Huesped;
import modelo.reservas_y_registro.Reserva;
import modelo.reservas_y_registro.Sistema_Reservas_y_Registro;
import modelo.servicios_y_consumo.Consumo;
import modelo.servicios_y_consumo.Producto;
import modelo.servicios_y_consumo.Servicio;
import modelo.servicios_y_consumo.Sistema_Consumos;
import modelo.servicios_y_consumo.Sistema_Servicios;
import modelo.usuarios.Administrador_Usuarios;
import modelo.usuarios.Usuario;

public class Hotel implements Serializable{

	private HashMap<Integer, Habitacion> Inventario; 
	
	private HashMap<String, String> Usuarios;
	
	private ArrayList<Huesped> Huespedes;
	
	private HashMap<Integer, ArrayList<Consumo>> Consumos;
	
	private BaseDatos Administrador_BD;
	
	private Sistema_Consumos sisConsumo;
	
	private Servicio servicio;
	
	private Producto producto;
	
	private Sistema_Servicios sistserv;
	
	private Administrador_Usuarios admin_usuarios;
	
	
	public Hotel() {
		this.Inventario = null;
		this.Usuarios = null;
		this.Huespedes = null;
		this.Consumos = null;
		this.Administrador_BD = new BaseDatos();
		this.sisConsumo =new Sistema_Consumos();
		this.sistserv=new Sistema_Servicios();
		this.admin_usuarios = new Administrador_Usuarios();
	}
	
	
	public void setInventario(){
		//Cargar archivo binario
	}
	
	public void setUsuarios(){
		//Cargar archivo binario
	}
	
	public void setHuespedes(){
		//Cargar archivo binario
	}
	
	public void setConsumos(){
		//Cargar archivo binario
	}
	
	
	
	
	
	
	
	
	
	
	public HashMap<Integer, Habitacion> getInventario() throws ClassNotFoundException, IOException{
		return Administrador_BD.GetInventario();
	}
	
	public HashMap<String, Usuario> getUsuarios() throws ClassNotFoundException, IOException{
		return Administrador_BD.GetUsuarios();
	}
	
	public HashMap<Integer, Huesped> getHuespedes() throws ClassNotFoundException, IOException{
		return Administrador_BD.GetHuespedes();
	}
	public HashMap<String, Servicio> GetServicios() throws ClassNotFoundException, IOException{
		return Administrador_BD.GetServicios();
	}
	public HashMap<String, Producto> GetMenu() throws ClassNotFoundException, IOException{
		return Administrador_BD.GetMenu();
	}
	
	public HashMap<Integer, ArrayList<Consumo>> GetConsumos() throws IOException, ClassNotFoundException {
		return Administrador_BD.GetConsumos();
	}
	
	public BaseDatos getBD(){
		return Administrador_BD;
	}
	
	

	public void eliminarReserva(long numeroReserva) throws ClassNotFoundException, IOException {
		Class<Reserva> clase = Reserva.class;
		Administrador_BD.EliminarObjeto(numeroReserva, clase);
		
	}
	public void eliminarObjeto(int numeroHabitacion) throws ClassNotFoundException, IOException {
		Class<Habitacion> clase = Habitacion.class;
		Administrador_BD.EliminarObjeto(numeroHabitacion, clase);
		
	}
	public void eliminar_ser_pro (String nombre)throws ClassNotFoundException, IOException {
		Map<String, Producto > menu = Administrador_BD.GetMenu();
		Map<String, Servicio > servicios = Administrador_BD.GetServicios();
		if (menu.containsKey(nombre)) {
			Producto clasesita =menu.get(nombre);
			String service = (menu.get(nombre)).getNombre();
			Class<?> clase = clasesita.getClass();
			Administrador_BD.EliminarObjeto(service, clase);
			System.out.println("Se ha eliminado el producto de: "+nombre);
		}
		if (servicios.containsKey(nombre)) {
			Servicio clasesita =servicios.get(nombre);   
			String service = (servicios.get(nombre)).getNombre();
			Class<?> clase = clasesita.getClass();
			Administrador_BD.EliminarObjeto(service, clase);
			System.out.println("Se ha eliminado el servicio de: "+nombre);
		}
		
	}
	
	

	
	//Aguirre
	public void guardarObjeto (String tipo, ArrayList<String> dias, String horas, int valor, String nombre) throws ClassNotFoundException, IOException {
		Servicio objeto = new Servicio( tipo, dias,  horas,  valor,  nombre);
		Administrador_BD.GuardarObjeto(objeto);
	}
	//métodos de consumo
	public void abrirConsumo (int numeroHabitacion) throws ClassNotFoundException, IOException {
		sisConsumo.abrir_registro_consumo(numeroHabitacion);
	}
	
	//métodos de servicios
	public void crear_servicio_file (String ruta) throws FileNotFoundException, IOException {
		sistserv.crear_servicio_file(ruta);
	}
	public void crear_servicio (String tipo,  String dias, String horario, int valor, String nombre) throws ClassNotFoundException, IOException {
		sistserv.crear_servicio(tipo, dias, horario, valor, nombre);
	}
	public void editar_servicio (int valor, String key) throws ClassNotFoundException, IOException {
		sistserv.editar_servicio(valor, key);
		
	}
	public void editar_servicio_file( String ruta) throws FileNotFoundException, IOException {
		sistserv.editar_servicio_file(ruta);
	}
	//métodos de productos
	public void crear_producto_file (String ruta) throws FileNotFoundException, IOException {
		sistserv.crear_producto_file(ruta);
	}
	public void crear_producto (String tipo,  String dias, String horario, int valor, String nombre, String dispoComi, String dispoTipo) throws ClassNotFoundException, IOException {
		sistserv.crear_producto(tipo, dias, horario, valor, nombre, dispoTipo, dispoTipo);
	}
	public void editar_producto (int valor, String key) throws ClassNotFoundException, IOException {
		sistserv.editar_producto(valor, key);
		
	}
	public void editar_producto_file( String ruta) throws FileNotFoundException, IOException {
		sistserv.editar_producto_file(ruta);
	}
	//métodos de consumo
	public void abrir_registro_consumo ( int habitacion_registrada) throws ClassNotFoundException, IOException {
		sisConsumo.abrir_registro_consumo(habitacion_registrada);
	}
	public void modificar_registro_consumo (int Habitacion_registrada,String name_service,boolean pago) throws ClassNotFoundException, IOException {
		sisConsumo.modificar_registro_consumo(Habitacion_registrada, name_service, pago);
	}
	public void eliminar_registro_consumo (int Habitacion_registrada) throws IOException, ClassNotFoundException {
		sisConsumo.eliminar_registro_consumo(Habitacion_registrada);
	}
	
	public Boolean Crear_sesion(String nombre, String clave, String tipo) throws ClassNotFoundException, IOException {
		return admin_usuarios.Crear_sesion(nombre, clave, tipo);
	}
	
	public Boolean Iniciar_sesion(String nombre, String clave, String tipo) throws ClassNotFoundException, IOException {
		return admin_usuarios.Iniciar_sesion(nombre, clave, tipo);
	}
	
	public Boolean Eliminar_cuenta(String nombre) throws ClassNotFoundException, IOException {
		return admin_usuarios.Eliminar_cuenta(nombre);
	}
	public String Generar_Factura(int numeroHabitacion) throws ClassNotFoundException, IOException {
		String factura = "Factura para la habitación " + Integer.toString(numeroHabitacion) + "\n";
		int cobrototal = 0;
		HashMap <Integer, ArrayList<Consumo>> consumos = Administrador_BD.GetConsumos();
		if (consumos.containsKey(numeroHabitacion)==false)
			return "No existe un registro de consumo asociado a esta habitacion";
		ArrayList<Consumo> listaconsumos = consumos.get(numeroHabitacion);
		for (Consumo element:listaconsumos) {
			if (element.isPago() == false) {
				factura += element.getServicio_consumido().getNombre() + "  Cobro:  " + Integer.toString(element.getCobro()) + "\n" ;
				cobrototal += element.getCobro();
			}
			
		}
		factura += "\nCobro total: " + Integer.toString(cobrototal);
		return factura;
	}
	
	// ************************************************************************
	// Métodos Sistema de inventarios
	// ************************************************************************
	
	//Habitaciones
	
	public void CargarHabitaciones(String archivo) throws FileNotFoundException, IOException, ClassNotFoundException {
		//El archivo es el nombre el nombre de la carpeta data
		Sistema_de_inventarios.Crear_habitacion_file(archivo, Administrador_BD); 
	}
	
	public void editar_habitaciones(int Ubicacion, int Camas_dobles_adultos, int Camas_individuales_adultos, int Camas_dobles_niños, int Camas_individuales_niños, int Tipo, boolean Balcon, boolean Vista, boolean Cocina) throws ClassNotFoundException, IOException   {
		Sistema_de_inventarios.Crear_Habitacion(Ubicacion, Camas_dobles_adultos, Camas_individuales_adultos, Camas_dobles_niños, Camas_individuales_niños, Tipo, Balcon, Vista, Cocina, Administrador_BD);
	}
	
	//Tarifas
	
	public void editar_tarifa_habitaciones_file(String archivo) throws ClassNotFoundException, IOException, ParseException {
		Sistema_de_inventarios.editar_tarifa_habitaciones_file(archivo, Administrador_BD);
	}
	
	public void editar_tarifa_habitaciones(String tipo, Date fecha_inicial, Date fecha_final, ArrayList<Integer> dias, int precio) throws ClassNotFoundException, IOException {
		Sistema_de_inventarios.Crear_Tarifa(tipo, fecha_inicial, fecha_final, dias, Administrador_BD, precio);
	}
	
	public ArrayList<ArrayList<Date>> Fechas_sin_tarifa(Date fecha_actual, Date fecha_después_365) throws ClassNotFoundException, IOException {
		ArrayList<ArrayList<Date>> respuesta = Sistema_de_inventarios.Fechas_sin_tarifa(fecha_actual, fecha_después_365, Administrador_BD);
		return respuesta;
	}
	
	// Consultar inventario
	
	// Consultar ocupación y reserva habitación
	
	
	
	
	// ************************************************************************
	// Métodos Sistema de reservas y resgitro
	// ************************************************************************
	
	//Reservas
	
	public ArrayList<Integer> reservar_file(String archivo, Date id_reserva) throws ClassNotFoundException, IOException, ParseException {
		ArrayList<Integer> respuesta = Sistema_Reservas_y_Registro.reservar_file(archivo, id_reserva, Administrador_BD);
		return respuesta;
	}
	
	public ArrayList<Integer> reservar(Huesped huesped_principal, int num_adultos, int num_ninos, int num_bebes_no_cama, int num_bebes_cama, Date fecha_inicio, Date fecha_final, Date id_reserva) throws ClassNotFoundException, IOException {
		
		ArrayList<Integer> respuesta = Sistema_Reservas_y_Registro.Crear_reserva( huesped_principal, num_adultos, num_ninos, num_bebes_no_cama, num_bebes_cama, fecha_inicio, fecha_final, id_reserva, Administrador_BD);
		return respuesta;
	}
	
	
	public void cancerlar_reserva() {
		
	}
	
	//Registro
	
	//Check out
	

}