package consola;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Set;

import modelo.Hotel;
import modelo.inventario_y_BD.BaseDatos;
import modelo.inventario_y_BD.Habitacion;
import modelo.reservas_y_registro.Huesped;
import modelo.reservas_y_registro.Reserva;
import modelo.servicios_y_consumo.Consumo;
import modelo.servicios_y_consumo.Producto;
import modelo.servicios_y_consumo.Servicio;





public class vista {
	
	private Hotel infoHotel;
	
	
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, ParseException {
		vista Aplicacion = new vista();
		Aplicacion.ejecutarAplicacion();
	}
	
	
	public void ejecutarAplicacion() throws IOException, ClassNotFoundException, ParseException {
		System.out.println("Hotel El Dorado");
		this.infoHotel = new Hotel();


		CrearArchivos();
		String ruta = new String("C://Users//Juan Esteban//Desktop//ANDES//2023-10//DPO//PMS//data/");
		
 		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarMenu_Usuarios();
				//obtener_consumo(505);
				int opcion_seleccionada = Integer.parseInt(input("Por favor selecciona una opción"));
				if (opcion_seleccionada == 1) {
					Boolean condicional = false;
					while(condicional==false) {
					String nombre = input("Indique el nombre de usuario");
					String clave = input("Indique la contraseña");
					int n = 0;
					String tipo = null; 
					while(n<1 | n>3) {
						mostrarMenuTipo();
						n = Integer.parseInt(input(""));
						if (n == 1) {
							tipo = "Administrador";
						}
						else if (n==2) {
							tipo = "Recepcionista";
						}
						else if (n==3) {
							tipo = "Empleado";
						}
						else {
							System.out.print("Seleccione una opción valida");
						}
								
					}
					condicional = infoHotel.Crear_sesion(nombre, clave, tipo);
					if (condicional)
						System.out.print("Sesión Creada correctamente\n");
					else
						System.out.print("El nombre de usuario ya existe\n");
					}
				}
					
				else if (opcion_seleccionada == 2 ) {
				Boolean condicional = false;
				while(condicional == false) {
				int n = 0;
				String tipo = null; 
				while(n<1 | n>3) {
					mostrarMenuTipo();
					System.out.println("4. Salir\n");
					n = Integer.parseInt(input(""));
					if (n == 1) {
						tipo = "Administrador";
					}
					else if (n==2) {
						tipo = "Recepcionista";
					}
					else if (n==3) {
						tipo = "Empleado";
					}
					else if(n==4)
						break;
					else {
						System.out.print("Seleccione una opción valida");
					}
							
				}
				if (n==4)
					break;
				String nombre = input("Indique el nombre de usuario");
				String clave = input("Indique la contraseña");
				
				condicional = infoHotel.Iniciar_sesion(nombre, clave, tipo);
				if (condicional) {
					if (tipo == "Administrador")
						administrador();
					else if(tipo == "Recepcionista")
						recepcionista();
					else if (tipo == "Empleado") {
						empleado();
					}
					}
				else {
					System.out.print("Inicio de sesión invalido. Su nombre de usuario o contraseña son incorrectos o su rol en el Hotel no tiene acceso a estas funciones.");
				}
				
				}
				}
					
				else if (opcion_seleccionada == 3 ) {
					String nombre = input("Escriba el nombre de usuario de la cuenta que quiere suprimir del sistema");
					Boolean condicional = infoHotel.Eliminar_cuenta(nombre);
					if (condicional) 
						System.out.print("Cuenta eliminada satisfactoriamente");
					else
						System.out.print("El usuario digitado no existe en el sistema");
				}
				else if (opcion_seleccionada == 4)
				{
					System.out.println("Saliendo de la aplicación ...");
					continuar = false;
				}else
				{
					System.out.println("Por favor seleccione una opción válida.");
				}
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los números de las opciones.");
			}
		}
		
		
		
	}
	public void recepcionista() throws IOException, ClassNotFoundException, ParseException {
		System.out.println("Interfaz de Recepcionista");
		this.infoHotel = new Hotel();
	


		CrearArchivos();
		String ruta = new String("C://Users//Juan Esteban//Desktop//ANDES//2023-10//DPO//PMS//data/");
		
 		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarMenu_recepcinista();
				//obtener_consumo(505);
				int opcion_seleccionada = Integer.parseInt(input("Por favor selecciona una opción"));
				if (opcion_seleccionada == 1)
					abrir_consumo();
				else if (opcion_seleccionada == 2 )
					modificar_consumo();
				else if (opcion_seleccionada == 3 )
					eliminar_consumo();
				else if (opcion_seleccionada == 4 )
					generar_factura();
				else if (opcion_seleccionada == 5 )
					hacer_reserva();
				else if (opcion_seleccionada == 6 )
					generar_factura();
				else if (opcion_seleccionada == 7)
				{
					System.out.println("Saliendo de la aplicación ...");
					continuar = false;
				}else
				{
					System.out.println("Por favor seleccione una opción válida.");
				}
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los números de las opciones.");
			}
		}
		
		
		
	}
	public void administrador() throws IOException, ClassNotFoundException, ParseException {
		System.out.println("Interfaz de Administrador");
		this.infoHotel = new Hotel();
	


		CrearArchivos();
		String ruta = new String("C://Users//Juan Esteban//Desktop//ANDES//2023-10//DPO//PMS//data/");
		
 		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarMenu_admin();
				//obtener_consumo(505);
				int opcion_seleccionada = Integer.parseInt(input("Por favor selecciona una opción"));
				if (opcion_seleccionada == 1)
					
					crear_servicio();
				else if (opcion_seleccionada == 2 )
					editar_tarifa_servicio();
				else if (opcion_seleccionada == 3 )
					crear_producto();
				else if (opcion_seleccionada == 4 )
					editar_tarifa_producto();
				else if (opcion_seleccionada == 5 )
					eliminar_ser_pro();
				else if (opcion_seleccionada == 6 )
					editar_tarifa_habitaciones();
				else if (opcion_seleccionada == 7 )
					editar_habitaciones();
				else if (opcion_seleccionada == 8)
				{
					System.out.println("Saliendo de la aplicación ...");
					continuar = false;
				}else
				{
					System.out.println("Por favor seleccione una opción válida.");
				}
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los números de las opciones.");
			}
		}
		
		
		
	}	
	
	public void empleado() throws IOException, ClassNotFoundException {
		System.out.println("Interfaz de Empleado ");
		this.infoHotel = new Hotel();
	


		CrearArchivos();
		String ruta = new String("C://Users//Juan Esteban//Desktop//ANDES//2023-10//DPO//PMS//data/");
		
 		boolean continuar = true;
		while (continuar)
		{
			try
			{
				mostrarMenu_empleado();
				//obtener_consumo(505);
				int opcion_seleccionada = Integer.parseInt(input("Por favor selecciona una opción"));
				if (opcion_seleccionada == 1)
					modificar_consumo();

				else if (opcion_seleccionada == 2)
				{
					System.out.println("Saliendo de la aplicación ...");
					continuar = false;
				}else
				{
					System.out.println("Por favor seleccione una opción válida.");
				}
			}
			catch (NumberFormatException e)
			{
				System.out.println("Debe seleccionar uno de los números de las opciones.");
			}
		}
		
		
		
	}
	public String input(String mensaje)
	{
		try
		{
			System.out.print(mensaje + ": ");
			BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
			return reader.readLine();
		}
		catch (IOException e)
		{
			System.out.println("Error leyendo de la consola");
			e.printStackTrace();
		}
		return null;
	}
	
	
	public void CrearArchivos() throws IOException {
		BaseDatos BD = infoHotel.getBD();
		BD.CrearArchivoConsumos();
		BD.CrearArchivoHuespedes();
		BD.CrearArchivoInventario();
		BD.CrearArchivoUsuarios();
		BD.CrearArchivoMenu();
		BD.CrearArchivoServicios();
		BD.CrearArchivoReservas();
		BD.CrearArchivoTarifa();
		BD.CrearArchivoOcupacion();
	}


	
	public void ObtenerInventario() throws ClassNotFoundException, IOException {
		Collection<Habitacion> inventario = infoHotel.getInventario().values();
		for (Habitacion element:inventario) {
			System.out.print(element.getNombreTipo());
			System.out.print("    ");
			System.out.print(element.getNumero());
			System.out.print("\n");
		}
		
	}
	private void obtenerServicios ()throws ClassNotFoundException, IOException {
	Collection<Servicio> servicios = infoHotel.GetServicios().values();
	//System.out.print(" joder   ");
	for (Servicio element:servicios) {
		//System.out.print(element.getValor());
		//System.out.print(" joder   ");
		System.out.print(element.toString());
		System.out.print("\n");
	}
	}
	private void obtenerMenu ()throws ClassNotFoundException, IOException {
		Collection<Producto> xd = infoHotel.GetMenu().values();
		//System.out.print(" joder   ");
		for (Producto element:xd) {
			//System.out.print(element.getValor());
			//System.out.print(" joder   ");
			System.out.print(element.toString());
			System.out.print("\n");
		}
		}
	private void obtener_consumo (int habitacion)throws ClassNotFoundException, IOException {
		HashMap<Integer, ArrayList<Consumo>>  xd = infoHotel.GetConsumos();
		if (xd.containsKey(habitacion)) {
			ArrayList<Consumo> lista =xd.get(habitacion);
			System.out.print("Habitación N.o: " +  habitacion);
			System.out.print("\n");
			int i=0;
			for (Consumo element:lista) {
				System.out.print("Consumo #"+i);
				System.out.print(element.toString());
				System.out.print("\n");
				
				i++;
				
			}	
		} else {
		System.out.print("La habitación: "+habitacion+ "no está en el registro");
		}
		
	}
	private void obtener_consumo_por_habitacion ()throws ClassNotFoundException, IOException {
		HashMap<Integer, ArrayList<Consumo>>  xd = infoHotel.GetConsumos();
		System.out.println("Habitaciones con registros de consumo: " );
		for (HashMap.Entry<Integer,  ArrayList<Consumo>> entry : xd.entrySet()) {
		    System.out.println("Habitación N.o: " + entry.getKey() );
		}
		
	}
	public void ObtenerHuespedes() throws ClassNotFoundException, IOException {
		Collection<Huesped> inventario = infoHotel.getHuespedes().values();
		for (Huesped element:inventario) {
			System.out.print(element.getNumero());
			System.out.print("    ");
			
		}
		
	}
	
	
		public void EliminarHabitacion(int numeroHabitacion) throws IOException, ClassNotFoundException {
			infoHotel.eliminarObjeto(numeroHabitacion); ;
		}
		public void eliminar_ser_pro ( )throws ClassNotFoundException, IOException {
			System.out.print("--CÁTALOGO DE SERVICIOS--");
	 		System.out.print("\n");
	 		obtenerServicios();
	 		System.out.print("--MENÚ DEL RESTAURANTE--");
	 		System.out.print("\n");
	 		obtenerMenu();
			String nombre =(input("Me podrías dar el nombre del servicio o producto"));
			infoHotel.eliminar_ser_pro(nombre);
		}
		
		
		public void objetoGuardar (String tipo, ArrayList<String> dias, String horas, int valor, String nombre) throws ClassNotFoundException, IOException {
			infoHotel.guardarObjeto( tipo,  dias,  horas,  valor,  nombre);
		}
		private void abrir_consumo() throws ClassNotFoundException, IOException {
			obtener_consumo_por_habitacion();
			int numero_hab = Integer.parseInt(input("Me podrías dar el número de la habitación pls"));
			infoHotel.abrir_registro_consumo(numero_hab);
		}
		private void modificar_consumo() throws ClassNotFoundException, IOException {
			obtener_consumo_por_habitacion();
			System.out.print("--CÁTALOGO DE SERVICIOS--");
	 		System.out.print("\n");
	 		obtenerServicios();
	 		System.out.print("--MENÚ DEL RESTAURANTE--");
	 		System.out.print("\n");
	 		obtenerMenu();
	 		
			int numero_hab = Integer.parseInt(input("Me podrías dar el número de la habitación pls"));
			System.out.print("Registro de Consumo actual");
			obtener_consumo(numero_hab);
	 		String consumo_servicio = (input("Me podrías dar el nombre del servicio a añadir"));
	 		boolean pagado= Boolean.parseBoolean(input("Me podrías dar indicar si el servicio está pago o no, gracias."));
			infoHotel.modificar_registro_consumo(numero_hab,consumo_servicio,pagado);
		}
		private void eliminar_consumo() throws ClassNotFoundException, IOException {
			obtener_consumo_por_habitacion();
			int numero_hab = Integer.parseInt(input("Me podrías dar el número de la habitación pls"));
			infoHotel.eliminar_registro_consumo(numero_hab);
		}
		public void crear_servicio() throws ClassNotFoundException, IOException {
			System.out.println("1. Crear un servicio por escritura");
			System.out.println("2. Crear un servicio por lectura de un archivo .txt");
			String consumo_servicio = (input("Elige una :D : "));
			if (consumo_servicio.equalsIgnoreCase("1")) {
				String nombre =(input("Me podrías dar el nombre del servicio"));
				int precio = Integer.parseInt(input("Me podrías dar el precio del servicio"));
				System.out.print("Lunes: L. Martes: M. Miércoles: X. Jueves: J. Viernes: V. Sábado: S. Domingo: D.");
		 		System.out.print("\n");
				String diasinput =(input("Me podrías dar los días a la semana (separados por -) Ej: L-V-D"));
				String tipo = "Servicio";
				String horario =(input("Me podrías dar el horaio de disponibilidad (sobre 24 hrs) Ej: 01-13"));
				infoHotel.crear_servicio(tipo, diasinput, horario, precio, nombre);
			}else {
				String archivo=(input("Me puedes dar el nombre del archivo a cargar plss (sernuevo.txt)"));
				String ruta = new String("./data/");
				String entrada= ruta;
			    entrada+=archivo;
				System.out.println(entrada);
				infoHotel.crear_servicio_file(entrada);
			}
		}
		public void editar_tarifa_servicio () throws ClassNotFoundException, IOException {
			System.out.println("1. Editar un servicio por escritura");
			System.out.println("2. Editar un servicio por lectura de un archivo .txt");
			String consumo_servicio = (input("Elige una :D : "));
			if (consumo_servicio.equalsIgnoreCase("1")) {
				System.out.print("--CÁTALOGO DE SERVICIOS--");
		 		System.out.print("\n");
		 		obtenerServicios();
				String nombre =(input("Me podrías dar el nombre del servicio"));
				int precio = Integer.parseInt(input("Me podrías dar el nuevo precio del servicio"));
				infoHotel.editar_servicio(precio, nombre);
			}else {
				String archivo=(input("Me puedes dar el nombre del archivo a cargar plss (serprecios.txt)"));
				String ruta = new String("./data/");
				String entrada= ruta;
			    entrada+=archivo;
				System.out.println(entrada);
				infoHotel.editar_servicio_file(entrada);
			}
		} public void generar_factura () throws ClassNotFoundException, IOException {
	
				String nombre =(input("Me podrías dar el nombre del servicio"));
				int precio = Integer.parseInt(input("Me podrías dar el número de la habitación"));
				infoHotel.Generar_Factura(precio);
			
		}
		public void crear_producto() throws ClassNotFoundException, IOException {
			System.out.println("1. Crear un producto por escritura");
			System.out.println("2. Crear un producto por lectura de un archivo .txt");
			String consumo_servicio = (input("Elige una :D : "));
			if (consumo_servicio.equalsIgnoreCase("1")) {
				String nombre =(input("Me podrías dar el nombre del producto"));
				int precio = Integer.parseInt(input("Me podrías dar el precio del producto"));
				System.out.print("Lunes: L. Martes: M. Miércoles: X. Jueves: J. Viernes: V. Sábado: S. Domingo: D.");
		 		System.out.print("\n");
				String diasinput =(input("Me podrías dar los días a la semana (separados por -) Ej: L-V-D"));
				String tipo = "Servicio";
				String horario =(input("Me podrías dar el horaio de disponibilidad (sobre 24 hrs) Ej: 01-13"));
				String disptipo =(input("Me podrías dar la disponibilidad del prodcuto (Comedor, Habitación)"));
				String consutipo =(input("Me podrías dar la disponibilidad de la comida (Permanente, Desayuno, Almuerzo, Cena)"));
				infoHotel.crear_producto(tipo, diasinput, horario, precio, nombre, consutipo, disptipo);
			}else {
				String archivo=(input("Me puedes dar el nombre del archivo a cargar plss (pronuevo.txt)"));
				String ruta = new String("./data/");
				String entrada= ruta;
			    entrada+=archivo;
				System.out.println(entrada);
				infoHotel.crear_producto_file(entrada);
			}
		}
		public void editar_tarifa_producto () throws ClassNotFoundException, IOException {
			System.out.println("1. Editar un producto por escritura");
			System.out.println("2. Editar un producto por lectura de un archivo .txt");
			String consumo_servicio = (input("Elige una :D : "));
			if (consumo_servicio.equalsIgnoreCase("1")) {
				System.out.print("--MENÚ DEL RESTAURANTE--");
		 		System.out.print("\n");
		 		obtenerMenu();
				String nombre =(input("Me podrías dar el nombre del producto"));
				int precio = Integer.parseInt(input("Me podrías dar el nuevo precio del producto"));
				infoHotel.editar_producto(precio, nombre);
			}else {
				String archivo=(input("Me puedes dar el nombre del archivo a cargar plss (proprecios.txt)"));
				String ruta = new String("./data/");
				String entrada= ruta;
			    entrada+=archivo;
				System.out.println(entrada);
				infoHotel.editar_producto_file(entrada);
			}
		}
		
		public void editar_tarifa_habitaciones () throws ClassNotFoundException, IOException, ParseException {
			
			//PRIMERO OBTENEMOS FECHA ACTUAL 
			
			SimpleDateFormat DateFormat = new SimpleDateFormat("dd/MM/yyyy");	
			
			Date fecha_actual_raw = new Date(); // fecha actual

			//fecha después de 365 días
			Calendar cal = Calendar.getInstance();
			cal.setTime(fecha_actual_raw);  
			cal.add(Calendar.DAY_OF_MONTH, 365); 
			Date fecha_después_365_raw = cal.getTime();
			
			//pasar a string fecha actual y después raw
			String fecha_actual_string = DateFormat.format(fecha_actual_raw);
			String fecha_después_365_string = DateFormat.format(fecha_después_365_raw);
			
			//las convertimos nuevamente en date con hora en 00:00:00
			Date fecha_actual = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_actual_string);
			Date fecha_después_365 = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_después_365_string);
			
			//HASTA AQUÍ OBTENEMOS FECHA ACTUAL 
			
			System.out.println("1. Editar tarifa por escritura");
			System.out.println("2. Editar tarifa por lectura de un archivo .txt");
			
			String consumo_servicio = (input("Elige una opción "));
			
			if (consumo_servicio.equalsIgnoreCase("1")) {
				
				String tipo =(input("Tipo de habitación ('estandar', 'suite', o 'suite doble')"));
				
				String fecha_inicial_raw =(input("Fecha inicial que aplica la tarifa 'dd/MM/yyyy'"));
				Date fecha_inicial = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_inicial_raw);
				
				String fecha_final_raw = (input("Fecha final que aplica la tarifa 'dd/MM/yyyy'"));
				Date fecha_final = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_final_raw);
				
				String dias_raw = (input("Días para los que aplica la tarifa (1 para Domingo, 2 para lunes, etc), separa por comas"));
				String[] dias_raw1 = dias_raw.split(",");
				ArrayList<Integer> dias = new ArrayList<Integer>();
				
				for (String i: dias_raw1) {
					int num = Integer.parseInt(i);
					dias.add(num);
				}	
				
				int precio = Integer.parseInt(input("Precio de las habitaciones"));
				infoHotel.editar_tarifa_habitaciones(tipo, fecha_inicial, fecha_final, dias, precio);
			
			}else {
				String archivo=(input("Me puedes dar el nombre del archivo a cargar (tarifa.txt)"));
				infoHotel.editar_tarifa_habitaciones_file(archivo);
			}
			
			System.out.println("Tarifas actualizadas con éxito\n");
			//Array con las fechas que no tienen tarifa definida para los próximos 365 días
			//El primer arreglo del array son las fechas sin tarifa para habitaciones estándar
			//El segundo arreglo del array son las fechas sin tarifa para habitaciones suite
			//El tercer arreglo del array son las fechas sin tarifa para habitaciones suite doble
			ArrayList<ArrayList<Date>> fechas_sin_tarifa = infoHotel.Fechas_sin_tarifa(fecha_actual, fecha_después_365);
			
			System.out.println("\n-Fechas dentro de los próximos 365 días en la que no exista una tarifa para hab. estándar:-\n");
			System.out.println(fechas_sin_tarifa.get(0));
			System.out.println("\n-Fechas dentro de los próximos 365 días en la que no exista una tarifa para hab. suite:-\n");
			System.out.println(fechas_sin_tarifa.get(1));
			System.out.println("\n-Fechas dentro de los próximos 365 días en la que no exista una tarifa para hab. suite doble:-\n");
			System.out.println(fechas_sin_tarifa.get(2));
			System.out.println('\n');
		} 
		
		public void editar_habitaciones () throws ClassNotFoundException, IOException, ParseException {
			System.out.println("1. Editar habitación por escritura");
			System.out.println("2. Editar habitación por lectura de un archivo .txt");
			String consumo_servicio = (input("Elige una opción"));
			if (consumo_servicio.equalsIgnoreCase("1")) {
				
				int id_y_ubicacion = Integer.parseInt(input("número o ubicación"));
				int camas_dobles_adultos = Integer.parseInt(input("cantidad camas_dobles_adultos"));
				int camas_individuales_adultos = Integer.parseInt(input("cantidad camas_individuales_adultos"));
				int camas_dobles_ninos = Integer.parseInt(input("cantidad camas_dobles_ninos"));
				int camas_individuales_ninos = Integer.parseInt(input("cantidad camas_individuales_ninos"));
				int tipo = Integer.parseInt(input("Tipo de habitación (0 para estándar, 1 para suite, o 2 para suite doble)"));
				
				String balcon_raw = input("¿Tiene balcón?, pon verdadero si sí");
				boolean balcon = balcon_raw.equals("verdadero") ? true : false;
				String vista_raw = input("¿Tiene vista?, pon verdadero si sí");
				boolean vista =  vista_raw.equals("verdadero") ? true : false;
				String cocina_raw = input("¿Tiene cocina?, pon verdadero si sí");
				boolean cocina =  cocina_raw.equals("verdadero") ? true : false;
				infoHotel.editar_habitaciones(id_y_ubicacion, camas_dobles_adultos, camas_individuales_adultos, camas_dobles_ninos, camas_individuales_ninos, tipo, balcon, vista, cocina);
				
			}else {
				String archivo=(input("Me puedes dar el nombre del archivo a cargar (habitaciones.txt)"));
				infoHotel.CargarHabitaciones("habitaciones.txt");
			}
			System.out.println("La habitación se editó correctamente");
		}
		
		public void hacer_reserva() throws ParseException, ClassNotFoundException, IOException {
			
			System.out.println("1. Hacer reserva por escritura");
			System.out.println("2. Hacer reserva por lectura de un archivo .txt");
			String consumo_servicio = (input("Elige una opción"));
			
			//PRIMERO OBTENEMOS FECHA ACTUAL 
			
			SimpleDateFormat DateFormat = new SimpleDateFormat("dd/MM/yyyy");	
			
			Date fecha_actual_raw = new Date(); // fecha actual

			//pasar a string fecha actual y después raw
			String fecha_actual_string = DateFormat.format(fecha_actual_raw);

			//las convertimos nuevamente en date con hora en 00:00:00
			Date fecha_actual = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_actual_string);

			//HASTA AQUÍ OBTENEMOS FECHA ACTUAL 
			
			ArrayList<Integer> respuesta = new ArrayList<Integer>(Arrays.asList(0,1,2));
					
			if (consumo_servicio.equalsIgnoreCase("1")) {
				String nombreHuesped =  input("nombre huesped");
				int documentoHuesped = Integer.parseInt(input("documento huesped"));
				String correoHuesped =  input("correo huesped");
				int celularHuesped = Integer.parseInt(input("celular huesped"));
				Huesped huespedPrincipal = new Huesped(nombreHuesped, correoHuesped, documentoHuesped, celularHuesped, Huesped.ADULTO);
				
				int Num_adultos = Integer.parseInt(input("numero adultos"));
				int Num_ninos = Integer.parseInt(input("numero de niños mayores de 2 años"));
				int Num_bebes_no_cama = Integer.parseInt(input("numero de niños menores de dos años que no necesitan cama"));
				int Num_bebes_cama = Integer.parseInt(input("numero de niños menores de dos años que si necesitan cama"));
				
				String fecha_inicial_raw = input("fecha inicial");
				Date fecha_inicial = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_inicial_raw);
				
				String fecha_final_raw = input("fecha final");
				Date fecha_final = new SimpleDateFormat("dd/MM/yyyy").parse(fecha_final_raw);
				
				respuesta = infoHotel.reservar(huespedPrincipal, Num_adultos, Num_ninos, Num_bebes_no_cama, Num_bebes_cama, fecha_inicial, fecha_final, fecha_actual);
				System.out.println("La reserva se hizo correctamente");
			
			} else {
				
				String archivo = (input("Me puedes dar el nombre del archivo a cargar (reservas.txt)"));
				respuesta = infoHotel.reservar_file("reservas.txt", fecha_actual);
				System.out.println("Las reservas se hicieron correctamente");
			}
			
			HashMap<Integer,Habitacion> inventario = infoHotel.getBD().GetInventario();
			HashMap<Date, ArrayList<Integer>> ocupacion =  infoHotel.getBD().GetOcupacion();
			HashMap<Date, Reserva> reservas =  infoHotel.getBD().GetReservas();
			
			Date fecha_inicial = new SimpleDateFormat("dd/MM/yyyy").parse("24/04/2023");
			Date fecha_final = new SimpleDateFormat("dd/MM/yyyy").parse("30/04/2023");
			
			System.out.println("\nVERIFICADOR DE OCUPACIÓN EN HABITACION Y ARCHIVO OCUPACION");
			for(int i:respuesta) {
				fecha_inicial = new SimpleDateFormat("dd/MM/yyyy").parse("24/04/2023");
				System.out.println("\n******************************");
				System.out.println("La habitacion es: " + i);
				System.out.println("\nLa ocupación es: " + inventario.get(i).getFechas_Ocupacion());
				
				if (i != 1 && i != 2 && i != 0) {
					while (fecha_inicial.compareTo(fecha_final) < 0 || fecha_inicial.compareTo(fecha_final)==0) {
						
						System.out.print("\nLa fecha es: " + fecha_inicial + ", Esta disponible la hab?: ");
						System.out.println(inventario.get(i).estaDisponible(fecha_inicial, fecha_inicial));
						System.out.println("En el archivo ocupacion esta disponible?: ");
						if ( ocupacion.get(fecha_inicial) == null )
							System.out.print( true + "\n" );
						else 
							System.out.print( ocupacion.get(fecha_inicial).contains(i) + "\n" );
						fecha_inicial = BaseDatos.getNextDay(fecha_inicial);
					}
				}
				System.out.println("\n******************************");
			}
			System.out.println("VERIFICADOR DE RESERVA");
			System.out.println(reservas.get(fecha_actual));

		}
		
		
		public void mostrarMenuTipo()
		{
			System.out.println("\nSeleccione que tipo de rol cumple en el Hotel\n");
			System.out.println("1. Administrador");
			System.out.println("2. Recepcionista");
			System.out.println("3. Empleado");
			
		}
		public void mostrarMenu_admin()
		{
			System.out.println("\nOpciones de la aplicación\n");
			
			System.out.println("1. Crear Servicio");
			System.out.println("2. Editar Tarifa de un Servicio");
			System.out.println("3. Crear Producto del Menú");
			System.out.println("4. Editar Tarifa de un producto del Menú");
			System.out.println("5. Eliminar un servicio o producto");
			System.out.println("6. Editar tarifa de las habitaciones");
			System.out.println("7. Cargar o actualizar habitaciones");
			System.out.println("8. Salir de la aplicación\n");
		
		}
		public void mostrarMenu_empleado()
		{
			System.out.println("\nOpciones de la aplicación\n");
			
			System.out.println("1. Modificar un registro de Consumo");
			System.out.println("2. Salir de la aplicación\n");
		}
		public void mostrarMenu_recepcinista()
		{
			System.out.println("\nOpciones de la aplicación\n");
			
			System.out.println("1. Abrir un registro de Consumo");
			System.out.println("2. Modificar un registro de Consumo");
			System.out.println("3. Eliminar un registro de Consumo");
			System.out.println("4. Generar factura");
			System.out.println("5. Hacer reserva");
			System.out.println("6. Hacer Check-out");
			System.out.println("7. Salir de la aplicación\n");
		}
		
		public void mostrarMenu_Usuarios()
		{
			System.out.println("\nOpciones de la aplicación\n");
			
			System.out.println("1. Crear Sesion");
			System.out.println("2. Iniciar Sesion");
			System.out.println("3. Eliminar Cuenta");
			System.out.println("4. Salir de la aplicación");
			
		}
}